<?php include_once('../config.php'); ?>
<!DOCTYPE html>
<html id = "bil" lang="ru" ng-app="bilpro" ng-controller = "bilController">
<head>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-107764072-14"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-107764072-14');
</script>
	<meta charset="UTF-8">
	<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1">
	<title>{{localization.events.title}}</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="../lib/ui/jquery-ui.min.css">
	<link rel="stylesheet" href="../lib/angular-growl/angular-growl.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<link rel="stylesheet" href="../styles/basket_v<?=$version;?>.css">
	<link rel="stylesheet" href="../styles/style_v<?=$version;?>.css">
	<link rel="stylesheet" href="../styles/custom-style_v<?=$version;?>.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src = "../lib/ui/jquery-ui.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-animate.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-resource.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-sanitize.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/ngStorage/0.3.6/ngStorage.min.js"></script>
	<script src = "../lib/angular-growl/angular-growl.min.js"></script>
	<script src = "../lib/jquery.maskedinput.min.js"></script>
	<script src = "../lib/modernizr-custom.js"></script>
	<script src = "../lib/moment.min.js"></script>
	<script src = "../scripts/city_v<?=$version;?>.js"></script>
	<script src = "../scripts/basket_v<?=$version;?>.js"></script>
	<script src = "../scripts/header_v<?=$version;?>.js"></script>
	<!--[if lt IE 9]>
	<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body class = "event-page">	

	<div class = "bil-main">
		<div growl></div>
		<div class = "bil-version"><?=$version;?> <?=$updated;?></div>
		<div class = "bil-header" ng-controller = "bilHeader">
			<?php include_once('../parts/mobile-header.php'); ?>
			<div class = "bil-wrapper">
				<div class = "bil-title" ng-show = "headerLoaded">
					<h1 class = "fade-in">{{cityName}}</h1>
					<div class = "menuTrigger" ng-click = "openMenu()">
						<svg viewBox="0 0 32 32"><path d="M4,10h24c1.104,0,2-0.896,2-2s-0.896-2-2-2H4C2.896,6,2,6.896,2,8S2.896,10,4,10z M28,14H4c-1.104,0-2,0.896-2,2 s0.896,2,2,2h24c1.104,0,2-0.896,2-2S29.104,14,28,14z M28,22H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h24c1.104,0,2-0.896,2-2 S29.104,22,28,22z"/></svg>
					</div>
					<div class = "authTrigger" ng-click = "openAuth()">
						<svg viewBox="0 0 350 350"><path d="M175,171.173c38.914,0,70.463-38.318,70.463-85.586C245.463,38.318,235.105,0,175,0s-70.465,38.318-70.465,85.587 C104.535,132.855,136.084,171.173,175,171.173z"/><path d="M41.909,301.853C41.897,298.971,41.885,301.041,41.909,301.853L41.909,301.853z"/><path d="M308.085,304.104C308.123,303.315,308.098,298.63,308.085,304.104L308.085,304.104z"/><path d="M307.935,298.397c-1.305-82.342-12.059-105.805-94.352-120.657c0,0-11.584,14.761-38.584,14.761 s-38.586-14.761-38.586-14.761c-81.395,14.69-92.803,37.805-94.303,117.982c-0.123,6.547-0.18,6.891-0.202,6.131 c0.005,1.424,0.011,4.058,0.011,8.651c0,0,19.592,39.496,133.08,39.496c113.486,0,133.08-39.496,133.08-39.496 c0-2.951,0.002-5.003,0.005-6.399C308.062,304.575,308.018,303.664,307.935,298.397z"/></svg>
					</div>
					<?php include_once('../parts/auth-popup.php'); ?>
				</div>
				<div class = "filterWrapper" ng-show = "headerLoaded">
					<div class = "filterElem">
						<select class = "form-control" ng-model = "config.venueID" ng-options = "venue.venueId as venue.venueName for venue in venueList" ng-change = "noResultsVisible()"></select>
					</div>
					<div class = "filterElem">
						<select class = "form-control" ng-model = "config.kindID" ng-options = "kind.kindId as kind.kindName for kind in kindList" ng-change = "noResultsVisible()"></select>
					</div>
					<div class = "filterElem">
						<input class = "form-control" ng-model = "config.date" datepicker ng-change = "noResultsVisible()">
					</div>
					<div class = "filterElem">
						<input class = "form-control" type = "text" placeholder = "поиск" ng-model = "config.search" ng-change = "noResultsVisible()">
					</div>
				</div>
				<div class = "loader-wrapper" ng-show = "!headerLoaded">
					<div class="loader"></div>
				</div>
			</div>
		</div>
		<div class = "bil-content">
			<div class="ghost-select"><span></span></div>
			<div class = "bil-wrapper">
				<div id = "grid" class = "eventsList clearfix">
					<a class = "eventItem" href = "../#/?id={{event.actionId}}&cityId={{config.cityID}}&venueId={{config.venueID}}&frontendId={{config.fid}}&token={{config.token}}&success={{config.successUrl}}&fail={{config.failUrl}}&agr={{config.agr}}&zone={{config.zone}}&lng={{config.lng}}" ng-repeat = "event in eventList" ng-if = "( inVenueMap(event.venueMap) || config.venueID == '-1' ) && ( laterThan(event.lastEventDate) ) && ( event.kindId == config.kindID || config.kindID == '-1' ) && ( config.search == '' || liveSearch(event.actionName, event.posterName) )">
						<img class = "eventItem-image" ng-src = "{{event.smallPosterUrl}}" image-onload = "setAsLoaded()">
						<div class = "eventItem-title">{{event.actionName}}</div>
						<div class = "eventItem-subtitle" ng-if = "event.actionName != event.fullActionName">{{event.fullActionName}}</div>
						<div class = "eventItem-description">{{event.posterName}}</div>
						<div class = "clearfix">
							<div class = "eventItem-price">{{localization.events.from}}<span>{{event.minSum}}</span>{{localization.currency}}.</div>
							<div class = "eventItem-date">{{event.firstEventDate}}<span ng-if = "event.firstEventDate != event.lastEventDate"> - {{event.lastEventDate}}</span></div>
							<div class = "eventItem-time" ng-if = "event.actionEventTime">{{event.actionEventTime}}</div>
							<div class = "eventItem-rating" ng-if = "event.rating >= 9">{{localization.events.rating}}<span class = "stars{{event.rating}}"></span></div>
						</div>
					</a>
				</div>
				<div class = "no-results" ng-show = "config.noResults">{{localization.noResultsTxt}}</div>
				<div class = "loader-wrapper" ng-show = "!contentLoaded">
					<div class="loader"></div>
				</div>
			</div>
		</div>
		<?php include_once('../parts/basket-popup.php'); ?>
	</div>
</body>
</html>
