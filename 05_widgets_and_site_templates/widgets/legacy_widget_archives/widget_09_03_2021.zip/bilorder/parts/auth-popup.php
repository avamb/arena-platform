<div id = "auth-popup" style = "display: none">
	<div class = "popup-title">{{localization.authPopupTitle}}</div>
	<div class = "message" ng-show = "message">{{message}}</div>
	<div class = "email-get">
		<form name = "userMail" class = "input-group" ng-submit = "SetEmail()" novalidate>
			<input class = "form-control" type = "email" placeholder = "{{localization.emailPlaceholder}}" ng-model="email" ng-pattern="/^([a-zA-Z0-9_-]+\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*\.[a-zA-Z]{2,6}$/" required>
			<span class = "input-group-btn">
				<button class = "btn btn-default" type = "submit" ng-disabled="userMail.$invalid || showConfirm">{{localization.settings.emailBtnTxt}}</button>
			</span>
		</form>
	</div>
	<div class = "email-confirm" ng-show = "showConfirm">
		<div class = "form-label">{{emailConfirmMsg}} <span>{{email}}</span></div>
		<form class = "input-group" ng-submit = "ConfirmEmail()" novalidate>
			<input class = "form-control" type = "text" ng-model="code" placeholder = "{{localization.emailPlaceholder}}" required>
			<span class = "input-group-btn">
				<button class = "btn btn-default" type = "submit">{{localization.settings.emailConfirmBtnTxt}}</button>
			</span>
		</form>
	</div>
</div>