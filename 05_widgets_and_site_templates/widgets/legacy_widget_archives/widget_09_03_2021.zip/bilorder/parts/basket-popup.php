<div ng-controller = "bilBasket">
	<div class = "basketMini" ng-show = "miniBasket.show" ng-class = "{'fade-in-down': miniBasket.show, 'fade-out-up': !miniBasket.show}">
		<div class = "basket-img"></div>
		<span class="badge chart-badge">{{miniBasket.count}}</span>
		<button class="btn btn-info" ng-click="FillBusket()">{{localization.basket.mini.btnTxt}}</button>
	</div>
	<div class = "basketFull" ng-show = "fullBasket.show" ng-class = "{'slide-in-right': fullBasket.show, 'slide-out-right': !fullBasket.show}">
		<div class = "basketFull-top clearfix">
			<button type="button" class="close" ng-click="fullBasket.loading = false; fullBasket.show = false">
				<span>×</span>
			</button>
			<div class = "time" ng-show = "tickets.timeout.format">{{tickets.timeout.format}}</div>
		</div>
		<div class = "loader-wrapper" ng-show = "fullBasket.loading">
			<div class="loader"></div>
		</div>
		<div class = "basketFull-content" ng-show = "!fullBasket.loading">
			<div class = "basketFull-empty" ng-show = "miniBasket.count == 0">{{localization.basket.full.isEmptyMsg}}</div>
			<div class = "basketFullItem" ng-repeat = "action in tickets.withPlace.data">
				<div class = "basketFullItem-action">{{action.actionName}}</div>
				<div class = "basketFullItem-venue">{{action.venueName}}</div>
				<div class = "basketFullItem-tickets">
					<div class = "basketFullItemTicket" ng-repeat = "ticket in action.seatList">
						<div class = "basketFullItemTicket-top">
							<div class = "basketFullItemTicket-place">
								<span ng-if = "ticket.sector && ticket.row && ticket.number">{{ticket.sector}} {{ticket.row}} {{ticket.number}}</span>
								<span ng-if = "!ticket.sector && !ticket.row && !ticket.number">{{ticket.categoryPriceName}}</span>
								<span ng-if = "ticket.tariffPlanName">{{localization.event.tariffs.Tariff}} {{ticket.tariffPlanName}}</span>
								<span ng-if = "!config.isGood">{{action.day}} {{action.time}}</span>
							</div>
							<div class = "basketFullItemTicket-price">
								<span class = "old" ng-if = "ticket.discount">{{ticket.nominal}} {{localization.currency}}</span>
								<span>{{ticket.price}} {{localization.currency}}</span>
							</div>
							<div class = "basketFullItemTicket-remove">
								<button type="button" class="close" ng-click="UnreserveTicket(ticket)">
									<span>×</span>
								</button>
							</div>
						</div>
						<div class = "basketFullItemTicket-bottom" ng-if = "ticket.discount">{{ticket.discountReason}}</div>
					</div>
				</div>
			</div>
			<div class = "basketFullBottom" ng-show = "miniBasket.count > 0">
				<div class = "basketFullBottom-charge clearfix" ng-show = "tickets.totalCharge > 0">
					<div class = "basketFullBottom-left">{{localization.basket.full.totalChargeTxt}}</div>
					<div class = "basketFullBottom-right">{{tickets.totalCharge}} {{localization.currency}}</div>
				</div>
				<div class = "basketFullBottom-sum clearfix">
					<div class = "basketFullBottom-right">{{tickets.totalSum}} {{localization.currency}}</div>
					<div class = "basketFullBottom-left">{{localization.basket.full.totalSumTxt}}</div>
				</div>
				<div class = "basketFullBottom-fullname clearfix" ng-if = "config.fullName.required">
					<input class = "form-control" type = "text" ng-model="config.fullName.value" placeholder = "{{localization.basket.full.fullNamePlaceholder}}">
				</div>
				<div class = "basketFullBottom-phone clearfix" ng-if = "config.phone.required">
					<input class = "form-control" type = "text" masked format="+7 (999)999-99-99" ng-model="config.phone.value" placeholder = "{{localization.basket.full.phonePlaceholder}}">
				</div>
				<form class = "basketFullBottom-promoCodes input-group" ng-submit = "SetBasketPromoCodes()" novalidate>
					<input class = "form-control" type = "text" ng-model="basketPromoCodes" placeholder = "{{localization.codes.setPlaceholderTxt}}" required>
					<span class = "input-group-btn">
						<button class = "btn btn-default" type = "submit" ng-disabled="disabledBasketPromoCodes">{{localization.codes.setBtn}}</button>
					</span>
				</form>
				<form class = "basketFullBottom-agreement">
					<input id = "agreement" type = "checkbox" ng-model="checkAgree">
					<label for = "agreement" ng-bind-html = "localization.agreement"></label>
					<div class = "text-center">
						<button class = "btn btn-info" ng-click = "CreateOrder()" ng-disabled="!checkAgree || (config.fullName.required && !config.fullName.value) || (config.phone.required && !config.phone.value)">{{localization.basket.full.buyBtnTxt}}</button>
						<button class = "btn btn-danger" ng-click = "UnreserveAll()" style = "margin-left: 10px">{{localization.basket.full.clearBtnTxt}}</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>