﻿<?
	$version = '2.012';
	$updated = '09.03.2021';
?>
