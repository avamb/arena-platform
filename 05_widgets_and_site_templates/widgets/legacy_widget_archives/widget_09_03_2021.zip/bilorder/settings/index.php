<?php include_once('../config.php'); ?>
<!DOCTYPE html>
<html id = "bil" lang="ru" ng-app="bilpro" ng-controller = "bilController">
<head>
	<meta charset="UTF-8">
	<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1">
	<title>{{localization.settings.title}}</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<link rel="stylesheet" href="../lib/angular-growl/angular-growl.min.css">
	<link rel="stylesheet" href="../styles/basket_v<?=$version;?>.css">
	<link rel="stylesheet" href="../styles/style_v<?=$version;?>.css">
	<link rel="stylesheet" href="../styles/custom-style_v<?=$version;?>.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src = "../lib/ui/jquery-ui.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-animate.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-resource.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-sanitize.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/ngStorage/0.3.6/ngStorage.min.js"></script>
	<script src = "../lib/angular-growl/angular-growl.min.js"></script>
	<script src = "../lib/jquery.maskedinput.min.js"></script>
	<script src = "../lib/modernizr-custom.js"></script>
	<script src = "../lib/moment.min.js"></script>
	<script src = "../scripts/settings_v<?=$version;?>.js"></script>
	<script src = "../scripts/basket_v<?=$version;?>.js"></script>
	<script src = "../scripts/header_v<?=$version;?>.js"></script>
	<!--[if lt IE 9]>
	<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body class = "cards-page">	

	<div class = "bil-main">
		<div growl></div>
		<div class = "bil-version"><?=$version;?> <?=$updated;?></div>
		<div class = "bil-header" ng-controller = "bilHeader">
			<?php include_once('../parts/mobile-header.php'); ?>
			<div class = "bil-wrapper">
				<div class = "bil-title">
					<h1 class = "fade-in">{{localization.settings.title}}</h1>
					<div class = "menuTrigger" ng-click = "openMenu()">
						<svg viewBox="0 0 32 32"><path d="M4,10h24c1.104,0,2-0.896,2-2s-0.896-2-2-2H4C2.896,6,2,6.896,2,8S2.896,10,4,10z M28,14H4c-1.104,0-2,0.896-2,2 s0.896,2,2,2h24c1.104,0,2-0.896,2-2S29.104,14,28,14z M28,22H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h24c1.104,0,2-0.896,2-2 S29.104,22,28,22z"/></svg>
					</div>
				</div>
			</div>
		</div>
		<div class = "bil-content">
			<div class="ghost-select"><span></span></div>
			<div class = "bil-wrapper">
				<div class = "email-get" ng-show = "contentLoaded && !config.noResults">
					<form name = "userMail" class = "input-group" ng-submit = "SetEmail()" novalidate>
						<input class = "form-control" type = "email" placeholder = "{{localization.emailPlaceholder}}" ng-model="email" ng-pattern="/^([a-zA-Z0-9_-]+\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*\.[a-zA-Z]{2,6}$/" required>
						<span class = "input-group-btn">
							<button class = "btn btn-default" type = "submit" ng-disabled="userMail.$invalid || showConfirm">{{localization.settings.emailBtnTxt}}</button>
						</span>
					</form>
				</div>
				<div class = "email-confirm" ng-show = "showConfirm">
					<div class = "form-label">{{emailConfirmMsg}} <span>{{email}}</span></div>
					<form class = "input-group" ng-submit = "ConfirmEmail()" novalidate>
						<input class = "form-control" type = "text" ng-model="code" placeholder = "{{localization.settings.emailConfirmPlaceholderTxt}}" required>
						<span class = "input-group-btn">
							<button class = "btn btn-default" type = "submit">{{localization.settings.emailConfirmBtnTxt}}</button>
						</span>
					</form>
				</div>
			</div>
		</div>
		<?php include_once('../parts/basket-popup.php'); ?>
	</div>
</body>
</html>
