(function() {

	'use strict';
	$.fancybox.defaults.touch = false;

	function isActive(url) {
		if( window.location.href.indexOf(url) != -1 ){
			return true;
		} else {
			return false;
		}
	}

	angular
		.module('bilpro')
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilHeader', bilHeader);

	function bilHeader($rootScope, $scope, $location, $localStorage, $interval, growl, Request) {

		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}
		
		Request.GetLocalization({local: local}).$promise.then(function(result) {

			console.log(result);
			$scope.localization = result;

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}

			if ( $scope.config.isGood ) {
				$scope.localization.emailPlaceholder = $scope.localization.settings.goods.emailPlaceholderTxt;
			} else {
				$scope.localization.emailPlaceholder = $scope.localization.settings.tickets.emailPlaceholderTxt;
			}

		})

		$scope.$watch('tickets.timeout.time', function() {
			// очищаем бронь
			if( $scope.tickets.timeout.time === 0 ){
				$interval.cancel($scope.tickets.timeout.function);
				// обновляем схему на странице представления
				$rootScope.$broadcast('shemeReinit');
				// обновляем контент в корзине
				$rootScope.$broadcast('basketReload');
				$scope.basketCount = 0;
				growl.error('Ваша бронь отменена');
			}
		})

		$scope.openMenu = function() {

			$scope.ticketsCount = 0;
			$scope.codesCount = 0;
			$scope.cardsCount = 0;

			// получаем количество билетов
			var tickets_getted = Request.GetRequest({command: 'GET_ACTION_EVENTS_GROUPED_BY_TICKETS', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( tickets_getted ){
				tickets_getted.$promise.then(function(results) {

					for (var key in results.list) {
						$scope.ticketsCount += results.list[key].quantity;
					}
					if( $scope.ticketsCount ){
						$('.ticketsCount').html(' - '+  $scope.ticketsCount);
					}

				});
			}

			// получаем список промокодов
			var codes_getted = Request.GetRequest({command: 'GET_PROMO_CODES', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( codes_getted ){
				codes_getted.$promise.then(function(results) {

					$.each(results.promoPackList, function(key, pack) {
						if(pack.activeNow){
							$.each(pack.promoCodeList, function(key, code) {
								if(code.used || code.spent){

								} else {
									$scope.codesCount += 1;
								}
							});
						}
					});

					if( $scope.codesCount ){
						$('.codesCount').html(' - '+  $scope.codesCount);
					}

				});
			}

			// получаем список карт
			var mecs_getted = Request.GetRequest({command: 'GET_MECS', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode, sizeQrCode: 400, widthBarCode: 400, heightBarCode: 125});
			if( mecs_getted ){

				mecs_getted.$promise.then(function(results) {
					$scope.cardsCount = results.list.length;
					if( $scope.cardsCount ){
						$('.cardsCount').html(' - '+  $scope.cardsCount);
					}

				});
			}

			var HTML = '<ul class = "menu">';
			var prefix;
			if( $('body').is('.home-page') ){
				prefix = '';
			} else {
				prefix = '../';
			}

			var params = $location.search();
			var postfix = '#/?';
			if( typeof params.id != 'undefined' ){
				postfix += 'id='+ params.id;
			}
			if( typeof params.cityId != 'undefined' ){
				postfix += '&cityId='+ params.cityId;
			}
			if( typeof params.venueId != 'undefined' ){
				postfix += '&venueId='+ params.venueId;
			}
			postfix += '&frontendId='+ params.frontendId +'&token='+ params.token +'&success='+ params.success +'&fail='+ params.fail +'&agr='+ params.agr +'&zone='+ params.zone +'&lng='+ params.lng;

			if( !isActive('/orders/') && !isActive('/tickets/') && !isActive('/cards/') && !isActive('/codes/') && !isActive('/settings/') ){
				HTML += '<li class = "menuItem"><span>'+ $scope.localization.events.menu +'</span></li>';
			} else {
				if( typeof params.id != 'undefined' ){
					HTML += '<li class = "menuItem"><a href = "'+ prefix + postfix +'">'+ $scope.localization.events.menu +'</a></li>';
				} else {
					HTML += '<li class = "menuItem"><a href = "'+ prefix +'city/'+ postfix +'">'+ $scope.localization.events.menu +'</a></li>';
				}

			}

			if( isActive('/orders/') ){
				HTML += '<li class = "menuItem"><span>'+ $scope.localization.orders.menu +'</span></li>';
			} else {
				HTML += '<li class = "menuItem"><a href = "'+ prefix +'orders/'+ postfix +'">'+ $scope.localization.orders.menu +'</a></li>';
			}

			if( isActive('/tickets/') ){
				HTML += '<li class = "menuItem"><span>'+ $scope.localization.tickets.menu +'</span><i class = "ticketsCount"></i></li>';
			} else {
				HTML += '<li class = "menuItem"><a href = "'+ prefix +'tickets/'+ postfix +'">'+ $scope.localization.tickets.menu +'</a><i class = "ticketsCount"></i></li>';
			}

			if( isActive('/cards/') ){
				HTML += '<li class = "menuItem"><span>'+ $scope.localization.cards.menu +'</span><i class = "cardsCount"></i></li>';
			} else {
				HTML += '<li class = "menuItem"><a href = "'+ prefix +'cards/'+ postfix +'">'+ $scope.localization.cards.menu +'</a><i class = "cardsCount"></i></li>';
			}

			if( isActive('/codes/') ){
				HTML += '<li class = "menuItem"><span>'+ $scope.localization.codes.menu +'</span><i class = "codesCount"></i></li>';
			} else {
				HTML += '<li class = "menuItem"><a href = "'+ prefix +'codes/'+ postfix +'">'+ $scope.localization.codes.menu +'</a><i class = "codesCount"></i></li>';
			}

			if( isActive('/settings/') ){
				HTML += '<div class = "menuItem"><span>'+ $scope.localization.settings.menu +'</span></li>';
			} else {
				HTML += '<li class = "menuItem"><a class = "menuItem" href = "'+ prefix +'settings/'+ postfix +'">'+ $scope.localization.settings.menu +'</a>';
			}

			HTML += '<li class = "menuItem"><a class = "menuItem" href = "'+ params.agr +'" target = "_blank">'+ $scope.localization.agreement.menu +'</a></li>';

			HTML += '</ul>';

			$.fancybox.open(HTML);

		}

		$scope.openAuth = function() {

			$.fancybox.open({
				'src': '#auth-popup',
				beforeShow: function() {

					// проверяем сохранены ли доступы в локальном хранилище
					var get_access = false;
					if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
						// в локальном хранилище было пусто, получаем новые доступы
						get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					} else {
						get_access = true;
					}

					// проверяем актуальность сохраненных доступов
					var check_access = false;
					if( get_access ){
						if( typeof get_access == 'object' ){
							get_access.$promise.then(function(results) {
								console.log(results);
								// если ошибок нет - сохраняем полученные доступы в куках
								if(results.resultCode == 101) {
									growl.error(results.description);
								} else if(results.resultCode == 0) {
									$localStorage.userId = results.userId;
									$localStorage.sessionId = results.sessionId;
								}
							});
						}
						check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

						var email_getted = false;
						$scope.showConfirm = false;
						if( check_access ){
							check_access.$promise.then(function(results) {
								console.log(results);
								if(results.resultCode == 101) {
									growl.error(results.description);
								} else if(results.resultCode == 0) {
									// проверяем почту
									email_getted = Request.GetRequest({command: 'GET_EMAIL', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
									if( email_getted ){
										email_getted.$promise.then(function(results) {
											console.log(results);
											if(results.resultCode == 101) {
												growl.error(results.description);
											} else if( results.resultCode == 0 && results.email != '' ){
												$scope.oldEmail = $scope.email = results.email;
											}
										});
									}

								}
							});
						}

					}

				}
			});

		}

		$scope.openBasket = function() {

			$rootScope.$broadcast('openBasket');

		}

		// функции для работы с почтой
		$scope.SetEmail = function(){
			if( $scope.email == $scope.oldEmail ){
				$scope.message = $scope.localization.settings.emailConfirmedYetMsg;
			} else {
				var email_setted = Request.GetRequest({command: 'BIND_EMAIL', email: $scope.email, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
				if( email_setted ){
					email_setted.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							$scope.message = results.description;
						} else if(results.resultCode == 0) {
							$scope.emailConfirmMsg = $scope.localization.settings.emailConfirmSendMsg;
							$scope.showConfirm = true;
						}
					});
				}
			}
		}
		$scope.ConfirmEmail = function(){
			var email_confirmed = Request.GetRequest({command: 'CONFIRM_EMAIL', code: $scope.code, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( email_confirmed ){
				email_confirmed.$promise.then(function(results) {
					console.log(results);
					if(results.resultCode != 0) {
						growl.error(results.description);
					} else {
						$scope.oldEmail = $scope.email = results.email;
						growl.success($scope.localization.settings.emailConfirmSuccessMsg);
						$scope.showConfirm = false;
						// проверяем соответсвуют ли сохраненные userId и sessionId пришедшим в ответе
						if( $localStorage.userId != results.userId || $localStorage.sessionId != results.sessionId ){
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
							location.reload();
						}
					}
				});
			}
		}

	}

})();