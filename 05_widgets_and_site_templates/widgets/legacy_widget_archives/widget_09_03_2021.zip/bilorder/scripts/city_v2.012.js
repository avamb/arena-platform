(function() {
	
	'use strict';
	$.fancybox.defaults.touch = false;

	$(window).resize(function(){
		$('#ui-datepicker-div').hide();
	});

	angular
		.module('bilpro', ['angular-growl','ngAnimate', 'ngResource', 'ngStorage', 'ngSanitize'])
		.factory('Request', Request)
		.directive('datepicker', datepicker)
		.directive('masked', masked)
		.directive('imageOnload', imageOnload)
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilController', bilController);

	function datepicker() {
		return {
			restrict: "A",
			require: "ngModel",
			link: function (scope, elem, attrs, ngModelCtrl) {
				var updateModel = function (dateText) {
					scope.$apply(function () {
						ngModelCtrl.$setViewValue(dateText);
					});
				};
				var options = {
					monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
					dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
					firstDay: 1,
					inline: true,
					dateFormat: 'dd.mm.yy',
					minDate: new Date(),
					onSelect: function (dateText) {
						updateModel(dateText);
					}
				};
				elem.datepicker(options);
			}
		}
	}

	function masked() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
				elm.mask(attrs.format, {
					completed: function() { 
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});
			}
		}
	}

	function imageOnload() {
		return {
			restrict: 'A',
			link: function(scope, element, attrs) {
				element.bind('load', function() {
					scope.$apply(function (){
						scope.$eval(attrs.imageOnload);
					});
					event.preventDefault();
				});
			}
		};
	}

	function Request($resource, $location) {

		var requestUrl;
		var params = $location.search();
	switch (params.zone) {
case 'real':
requestUrl = 'https://api.bil24.pro:443/json';
break;
case 'test':
requestUrl = 'https://api.bil24.pro:1240/json';
break;
default:
requestUrl = 'https://api.bil24.pro:'+ params.zone +'/json';
break;
}

		return $resource(requestUrl, {
			fid: '@fid',
			token: '@token',
			versionCode: '@versionCode',
			command: '@command',
			phone: '@phone',
			fullName: '@fullName',
			userId: '@userId',
			sessionId: '@sessionId'
		}, {
			GetRequest: {
				method: 'POST',
				isArray: false
			},
			GetLocalization: {
				method: 'GET',
				isArray: false,
				url: '/bilorder/localization/:local'
			}
		});
	}

	function bilController($rootScope, $scope, $location, $localStorage, $resource, $interval, $timeout, growl, Request) {

		$scope.headerLoaded = false;
		$scope.contentLoaded = false;
		var counter;

		$scope.config = {
			cityID: false,
			venueID: -1,
			kindID: -1,
			search: '',
			fullName: {
				required: false,
				value: ''
			},
			phone: {
				required: false,
				value: ''
			},
			noResults: false
		}
		$scope.tickets = {
			timeout: {
				function: false,
				time: false,
				format: false
			},
			withPlace: {
				data: [],
				count: 0,
				show: false,
				noResults: false
			},
			withoutPlace: {
				data: {},
				count: 0,
				show: false
			},
			totalCharge: 0,
			totalSum: 0
		};
		$scope.miniBasket = {
			count: 0,
			show: false
		};
		$scope.fullBasket = {
			filled: false,
			loading: false,
			show: false
		}
		$scope.config.kindID = -1;

		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}

		if ( params.goods == 'true' ) {
			$scope.config.isGood = true;
		}

		Request.GetLocalization({local: local}).$promise.then(function(result) {
			console.log(result);
			$scope.localization = result;

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}
			if ( typeof params.cityId != 'undefined') {
				$scope.config.cityID = params.cityId;
			}
			if ( typeof params.success != 'undefined' && params.success != 'appsuccess' ) {
				$scope.config.successUrl = params.success;
			} else {
				$scope.config.successUrl = 'http://bilw.ru/TAC/pay_s.html';
			}
			if ( typeof params.fail != 'undefined' && params.fail != 'appfail' ) {
				$scope.config.failUrl = params.fail;
			} else {
				$scope.config.failUrl = 'http://bilw.ru/TAC/pay_f.html';
			}
			if ( typeof params.agr != 'undefined' ) {
				$scope.config.agr = params.agr;
			}
			if ( typeof params.zone != 'undefined') {
				$scope.config.zone = params.zone;
			}
			if ( typeof params.lng != 'undefined') {
				$scope.config.lng = params.lng;
			}

			// проверяем сохранены ли доступы в локальном хранилище
			var get_access = false;
			if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
				// в локальном хранилище было пусто, получаем новые доступы
				get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			} else {
				get_access = true;
			}

			// проверяем актуальность сохраненных доступов
			var check_access = false;
			if( get_access ){
				if( typeof get_access == 'object' ){
					get_access.$promise.then(function(results) {
						console.log(results);
						// если ошибок нет - сохраняем полученные доступы в куках
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
						}
					});
				}
				check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

				var get_filter = false;
				if( check_access ){
					check_access.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							// проверяем корзину
							$rootScope.$broadcast('getCart', { callback: false} );

							// получаем список городов
							get_filter = Request.GetRequest({command: 'GET_FILTER', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

							if( get_filter ){
								get_filter.$promise.then(function(results) {
									console.log(results);
									if(results.resultCode == 101) {
										growl.error(results.description);
									} else if(results.resultCode == 0) {
										$scope.cityList = results.cityList;
										$scope.kindList = [{
											'kindId': -1,
											'kindName': 'все виды'
										}];
										$.each(results.kindList, function(index, value){
											$scope.kindList[index + 1] = {
												'kindId': value.kindId,
												'kindName': value.kindName
											}
										});
										$scope.config.date = $scope.minDate = moment( new Date() ).format('DD.MM.YYYY');
										for (var key_city in results.cityList) {
											if( results.cityList[key_city].cityId == $scope.config.cityID ) {
												$scope.cityName = results.cityList[key_city].cityName;
												$scope.venueList = [{
													'venueId': -1,
													'venueName': 'все площадки'
												}];
												$.each($scope.cityList[key_city].venueList, function(index, value){
													if ( typeof params.venueId != 'undefined' && params.venueId == value.venueId ) {
														$scope.config.venueID = value.venueId;
													}
													$scope.venueList[index + 1] = {
														'venueId': value.venueId,
														'venueName': value.venueName
													}
												});
											}
										}
										$scope.headerLoaded = true;
									}
								});
							}

							// получаем список представлений
							var actions_getted = Request.GetRequest({command: 'GET_ACTIONS_V2', cityId: $scope.config.cityID, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
							if( actions_getted ){
								actions_getted.$promise.then(function(results) {
									console.log(results);
									if(results.resultCode == 101) {
										growl.error(results.description);
									} else if(results.resultCode == 0) {
										if( results.actionList.length == 0 ){
											$scope.config.noResults = true;
											$scope.contentLoaded = true;
										} else {
											$scope.eventList = results.actionList;
											counter = 0;
										}
									}
								});
							}

						}
					});
				}

			}

			$scope.setAsLoaded = function() {
				counter++;
				if( counter == $('.eventItem').length ){
					$timeout(function(){
						$scope.contentLoaded = true;
					}, 1000);
				}
			}
			$scope.$watch('contentLoaded', function(){
				var grid = document.getElementById('grid');
				if( $scope.contentLoaded ){
					grid.style.height = 'auto';
					grid.style.overlow = 'visible';
					grid.style.opacity = 1;
				} else {
					grid.style.height = '0px';
					grid.style.overlow = 'hidden';
					grid.style.opacity = 0;
				}
			});

			// площадка
			$scope.inVenueMap = function(venueMap) {
				for (var key_venue in venueMap) {
					if( $scope.config.venueID == key_venue ){
						return true;
					}
				}
			}

			// дата мероприятия
			$scope.getDate = function(event) {
				return moment(event.firstEventDate, 'DD.MM.YYYY');
			}
			$scope.laterThan = function(eventDate) {
				return moment(eventDate, 'DD.MM.YYYY').isAfter( moment($scope.config.date, 'DD.MM.YYYY').subtract(1, 'days') );
			}

			// по совпадению
			$scope.liveSearch = function(title, description){
				if( title.toLowerCase().indexOf( $scope.config.search.toLowerCase() ) != -1 || description.toLowerCase().indexOf( $scope.config.search.toLowerCase() ) != -1 ) {
					return true;
				}
			}

			$scope.noResultsVisible = function() {
				$timeout(function(){
					if( $('.eventItem').length == 0 ){
						$scope.config.noResults = true;
					} else {
						$scope.config.noResults = false;
					}
				}, 100);
			}

		});

	}

})();