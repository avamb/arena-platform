(function() {

	'use strict';
	$.fancybox.defaults.touch = false;

	angular
		.module('bilpro', ['angular-growl','ngAnimate', 'ngResource', 'ngStorage', 'ngSanitize'])
		.factory('Request', Request)
		.directive('masked', masked)
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilController', bilController);

	function masked() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
				elm.mask(attrs.format, {
					completed: function() { 
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});
			}
		}
	}

	function Request($resource, $location) {

		var requestUrl;
		var params = $location.search();
		switch (params.zone) {
case 'real':
requestUrl = 'https://api.bil24.pro:443/json';
break;
case 'test':
requestUrl = 'https://api.bil24.pro:1240/json';
break;
default:
requestUrl = 'https://api.bil24.pro:'+ params.zone +'/json';
break;
}

		return $resource(requestUrl, {
			fid: '@fid',
			token: '@token',
			versionCode: '@versionCode',
			command: '@command',
			phone: '@phone',
			fullName: '@fullName',
			userId: '@userId',
			sessionId: '@sessionId'
		}, {
			GetRequest: {
				method: 'POST',
				isArray: false
			},
			GetLocalization: {
				method: 'GET',
				isArray: false,
				url: '/bilorder/localization/:local'
			}
		});
	}

	function bilController($rootScope, $scope, $location, $localStorage, $resource, $interval, $timeout, growl, Request) {

		$scope.contentLoaded = false;
		var counter;

		$scope.config = {
			fullName: {
				required: false,
				value: ''
			},
			phone: {
				required: false,
				value: ''
			}
		}
		$scope.tickets = {
			timeout: {
				function: false,
				time: false,
				format: false
			},
			withPlace: {
				data: [],
				count: 0,
				show: false,
				noResults: false
			},
			withoutPlace: {
				data: {},
				count: 0,
				show: false
			},
			totalCharge: 0,
			totalSum: 0
		};
		$scope.miniBasket = {
			count: 0,
			show: false
		};
		$scope.fullBasket = {
			filled: false,
			loading: false,
			show: false
		}

		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}

		if ( params.goods == 'true' ) {
			$scope.config.isGood = true;
		}

		Request.GetLocalization({local: local}).$promise.then(function(result) {
			console.log(result);
			$scope.localization = result;
			$scope.localization.noResultsText = $scope.localization['noResultsText'];

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}
			if ( typeof params.success != 'undefined' && params.success != 'appsuccess' ) {
				$scope.config.successUrl = params.success;
			} else {
				$scope.config.successUrl = 'http://bilw.ru/TAC/pay_s.html';
			}
			if ( typeof params.fail != 'undefined' && params.fail != 'appfail' ) {
				$scope.config.failUrl = params.fail;
			} else {
				$scope.config.failUrl = 'http://bilw.ru/TAC/pay_f.html';
			}
			if ( typeof params.zone != 'undefined') {
				$scope.config.zone = params.zone;
			}
			if ( typeof params.lng != 'undefined') {
				$scope.config.lng = params.lng;
			}

			// проверяем сохранены ли доступы в локальном хранилище
			var get_access = false;
			if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
				// в локальном хранилище было пусто, получаем новые доступы
				get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			} else {
				get_access = true;
			}

			// проверяем актуальность сохраненных доступов
			var check_access = false;
			if( get_access ){
				if( typeof get_access == 'object' ){
					get_access.$promise.then(function(results) {
						console.log(results);
						// если ошибок нет - сохраняем полученные доступы в куках
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
						}
					});
				}
				check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

				var email_getted = false;
				$scope.showConfirm = false;
				if( check_access ){
					check_access.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							// проверяем почту
							email_getted = Request.GetRequest({command: 'GET_EMAIL', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
							if( email_getted ){
								email_getted.$promise.then(function(results) {
									console.log(results);
									if(results.resultCode == 101) {
										growl.error(results.description);
									} else if( results.resultCode == 0 && results.email != '' ){
										$scope.oldEmail = $scope.email = results.email;
									}
								});
							}

							// проверяем корзину
							$rootScope.$broadcast('getCart', { callback: false} );

							$scope.contentLoaded = true;

						}
					});
				}

			}

			// функции для работы с почтой
			$scope.SetEmail = function(){
				if( $scope.email == $scope.oldEmail ){
					growl.error($scope.localization.settings.emailConfirmedYetMsg);
				} else {
					var email_setted = Request.GetRequest({command: 'BIND_EMAIL', email: $scope.email, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( email_setted ){
						email_setted.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
							} else if(results.resultCode == 0) {
								$scope.emailConfirmMsg = $scope.localization.settings.emailConfirmSendMsg;
								$scope.showConfirm = true;
							}
						});
					}
				}
			}
			$scope.ConfirmEmail = function(){
				var email_confirmed = Request.GetRequest({command: 'CONFIRM_EMAIL', code: $scope.code, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
				if( email_confirmed ){
					email_confirmed.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode != 0) {
							growl.error(results.description);
						} else {
							$scope.oldEmail = $scope.email = results.email;
							growl.success($scope.localization.settings.emailConfirmSuccessMsg);
							$scope.showConfirm = false;
							// проверяем соответсвуют ли сохраненные userId и sessionId пришедшим в ответе
							if( $localStorage.userId != results.userId || $localStorage.sessionId != results.sessionId ){
								$localStorage.userId = results.userId;
								$localStorage.sessionId = results.sessionId;
							}
							$rootScope.$broadcast('getCart', { callback: false} );
						}
					});
				}
			}

		});

	}

})();
