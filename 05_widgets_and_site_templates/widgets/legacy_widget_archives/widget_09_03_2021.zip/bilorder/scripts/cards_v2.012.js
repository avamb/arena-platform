(function() {

	'use strict';
	$.fancybox.defaults.touch = false;

	angular
		.module('bilpro', ['angular-growl','ngAnimate', 'ngResource', 'ngStorage', 'ngSanitize'])
		.factory('Request', Request)
		.directive('masked', masked)
		.directive('imageOnload', imageOnload)
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilController', bilController);

	function masked() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
				elm.mask(attrs.format, {
					completed: function() { 
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});
			}
		}
	}

	function imageOnload() {
		return {
			restrict: 'A',
			link: function(scope, element, attrs) {
				element.bind('load', function() {
					scope.$apply(function (){
						scope.$eval(attrs.imageOnload);
					});
					event.preventDefault();
				});
			}
		};
	}

	function Request($resource, $location) {

		var requestUrl;
		var params = $location.search();
		switch (params.zone) {
case 'real':
requestUrl = 'https://api.bil24.pro:443/json';
break;
case 'test':
requestUrl = 'https://api.bil24.pro:1240/json';
break;
default:
requestUrl = 'https://api.bil24.pro:'+ params.zone +'/json';
break;
}

		return $resource(requestUrl, {
			fid: '@fid',
			token: '@token',
			versionCode: '@versionCode',
			command: '@command',
			phone: '@phone',
			fullName: '@fullName',
			userId: '@userId',
			sessionId: '@sessionId'
		}, {
			GetRequest: {
				method: 'POST',
				isArray: false
			},
			GetLocalization: {
				method: 'GET',
				isArray: false,
				url: '/bilorder/localization/:local'
			}
		});
	}

	function bilController($rootScope, $scope, $location, $localStorage, $resource, $interval, $timeout, growl, Request) {

		$scope.contentLoaded = false;
		var counter;

		$scope.config = {
			fullName: {
				required: false,
				value: ''
			},
			phone: {
				required: false,
				value: ''
			}
		}
		$scope.tickets = {
			timeout: {
				function: false,
				time: false,
				format: false
			},
			withPlace: {
				data: [],
				count: 0,
				show: false,
				noResults: false
			},
			withoutPlace: {
				data: {},
				count: 0,
				show: false
			},
			totalCharge: 0,
			totalSum: 0
		};
		$scope.miniBasket = {
			count: 0,
			show: false
		};
		$scope.fullBasket = {
			filled: false,
			loading: false,
			show: false
		}

		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}

		if ( params.goods == 'true' ) {
			$scope.config.isGood = true;
		}

		Request.GetLocalization({local: local}).$promise.then(function(result) {
			console.log(result);
			$scope.localization = result;

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}
			if ( typeof params.success != 'undefined' && params.success != 'appsuccess' ) {
				$scope.config.successUrl = params.success;
			} else {
				$scope.config.successUrl = 'http://bilw.ru/TAC/pay_s.html';
			}
			if ( typeof params.fail != 'undefined' && params.fail != 'appfail' ) {
				$scope.config.failUrl = params.fail;
			} else {
				$scope.config.failUrl = 'http://bilw.ru/TAC/pay_f.html';
			}
			if ( typeof params.zone != 'undefined') {
				$scope.config.zone = params.zone;
			}
			if ( typeof params.lng != 'undefined') {
				$scope.config.lng = params.lng;
			}

			// проверяем сохранены ли доступы в локальном хранилище
			var get_access = false;
			if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
				// в локальном хранилище было пусто, получаем новые доступы
				get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			} else {
				get_access = true;
			}

			// проверяем актуальность сохраненных доступов
			var check_access = false;
			if( get_access ){
				if( typeof get_access == 'object' ){
					get_access.$promise.then(function(results) {
						console.log(results);
						// если ошибок нет - сохраняем полученные доступы в куках
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
						}
					});
				}
				check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

				if( check_access ){
					check_access.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							// проверяем корзину
							$rootScope.$broadcast('getCart', { callback: false} );

							// получаем список карт
							var mecs_getted = Request.GetRequest({command: 'GET_MECS', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode, sizeQrCode: 400, widthBarCode: 400, heightBarCode: 125});
							if( mecs_getted ){
								mecs_getted.$promise.then(function(results) {
									console.log(results);
									if( results.list.length == 0 ){
										growl.error($scope.localization.cards.noResults, {ttl: -1} );
										$scope.contentLoaded = true;
										$scope.cardsList = false;
										angular.element('#content .preloader').hide();
									} else {
										$scope.cardsList = results.list;
										counter = results.list.length;
									}
								});
								$scope.contentLoaded = true;
							}

						}
					});
				}

			}

			$scope.setAsLoaded = function() {
				counter++;
				if( counter == $('.eventItem').length ){
					$timeout(function(){
						$scope.contentLoaded = true;
					}, 1000);
				}
			}
			$scope.$watch('contentLoaded', function(){
				var grid = document.getElementById('grid');
				if( $scope.contentLoaded ){
					grid.style.height = 'auto';
					grid.style.overlow = 'visible';
					grid.style.opacity = 1;
				} else {
					grid.style.height = '0px';
					grid.style.overlow = 'hidden';
					grid.style.opacity = 0;
				}
			});

			$scope.OpenCardsList = function(actionEventId){
				$.each($scope.cardsList, function(key, card) {
					if(card.actionEventId == actionEventId){
						var html = '<div id = "cards-popup"><div class = "popup-title">'+ $scope.localization.cards.labelTxt +' "'+ card.actionName +'"</div><div class = "mecsList">';
							$.each(card.mecList, function(key, mec) {
								html += '<div class = "mecItem" data-card = "'+ card.actionEventId +'"data-mec = "'+ mec.mecId +'"><div class = "mecItem-left"><p>'+ $scope.localization.cards.totalTxt +' '+ mec.price +' '+ $scope.localization.currency +'</p><p>'+ mec.categoryName +'</p><p>'+ $scope.localization.cards.cityTxt +' '+ card.cityName +'</p></div><div class = "mecItem-right"><img src="data:image/png;base64,'+ mec.barCodeImg +'"/>'+ mec.barCodeNumber +'</div></div>';
							});
						html += '</div></div>';
						$.fancybox.open(html);
					}
				});
			}

			$(document).on('click', '.mecItem', function(){
				var $this = $(this);
				$.each($scope.cardsList, function(key, card) {
					if( card.actionEventId == $this.attr('data-card') ){
						$.each(card.mecList, function(key, mec) {
							if( mec.mecId == $this.attr('data-mec') ){
								var html = '<div id = "card-popup"><img src="data:image/png;base64,'+ mec.barCodeImg +'"/><img src="data:image/png;base64,'+ mec.qrCodeImg +'"/><p>'+ $scope.localization.cards.numberTxt +' '+ mec.mecId +'</p><p>'+ mec.categoryName +'</p><p>'+ card.venueName +'</p><p>'+ $scope.localization.cards.priceTxt +' '+ mec.price +' '+ $scope.localization.currency +'</p></div>';
								$.fancybox.close();
								$.fancybox.open(html);
							}
						});
					}
				});
			});

		});

	}

})();
