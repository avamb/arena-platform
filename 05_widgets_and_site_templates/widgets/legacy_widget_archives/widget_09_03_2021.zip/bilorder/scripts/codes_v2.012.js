(function() {

	'use strict';
	$.fancybox.defaults.touch = false;

	angular
		.module('bilpro', ['angular-growl','ngAnimate', 'ngResource', 'ngStorage', 'ngSanitize'])
		.factory('Request', Request)
		.directive('masked', masked)
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilController', bilController);

	function masked() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
				elm.mask(attrs.format, {
					completed: function() { 
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});
			}
		}
	}

	function Request($resource, $location) {

		var requestUrl;
		var params = $location.search();
		switch (params.zone) {
case 'real':
requestUrl = 'https://api.bil24.pro:443/json';
break;
case 'test':
requestUrl = 'https://api.bil24.pro:1240/json';
break;
default:
requestUrl = 'https://api.bil24.pro:'+ params.zone +'/json';
break;
}

		return $resource(requestUrl, {
			fid: '@fid',
			token: '@token',
			versionCode: '@versionCode',
			command: '@command',
			phone: '@phone',
			fullName: '@fullName',
			userId: '@userId',
			sessionId: '@sessionId'
		}, {
			GetRequest: {
				method: 'POST',
				isArray: false
			},
			GetLocalization: {
				method: 'GET',
				isArray: false,
				url: '/bilorder/localization/:local'
			}
		});
	}

	function bilController($rootScope, $scope, $location, $localStorage, $resource, $interval, $timeout, growl, Request) {

		$scope.contentLoaded = false;
		var counter;

		$scope.config = {
			fullName: {
				required: false,
				value: ''
			},
			phone: {
				required: false,
				value: ''
			}
		}
		$scope.tickets = {
			timeout: {
				function: false,
				time: false,
				format: false
			},
			withPlace: {
				data: [],
				count: 0,
				show: false,
				noResults: false
			},
			withoutPlace: {
				data: {},
				count: 0,
				show: false
			},
			totalCharge: 0,
			totalSum: 0
		};
		$scope.miniBasket = {
			count: 0,
			show: false
		};
		$scope.fullBasket = {
			filled: false,
			loading: false,
			show: false
		}

		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}

		if ( params.goods == 'true' ) {
			$scope.config.isGood = true;
		}

		Request.GetLocalization({local: local}).$promise.then(function(result) {
			console.log(result);
			$scope.localization = result;

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}
			if ( typeof params.success != 'undefined' && params.success != 'appsuccess' ) {
				$scope.config.successUrl = params.success;
			} else {
				$scope.config.successUrl = 'http://bilw.ru/TAC/pay_s.html';
			}
			if ( typeof params.fail != 'undefined' && params.fail != 'appfail' ) {
				$scope.config.failUrl = params.fail;
			} else {
				$scope.config.failUrl = 'http://bilw.ru/TAC/pay_f.html';
			}
			if ( typeof params.zone != 'undefined') {
				$scope.config.zone = params.zone;
			}
			if ( typeof params.lng != 'undefined') {
				$scope.config.lng = params.lng;
			}

			// проверяем сохранены ли доступы в локальном хранилище
			var get_access = false;
			if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
				// в локальном хранилище было пусто, получаем новые доступы
				get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			} else {
				get_access = true;
			}

			// проверяем актуальность сохраненных доступов
			var check_access = false;
			if( get_access ){
				if( typeof get_access == 'object' ){
					get_access.$promise.then(function(results) {
						console.log(results);
						// если ошибок нет - сохраняем полученные доступы в куках
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
						}
					});
				}
				check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

				if( check_access ){
					check_access.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							// проверяем корзину
							$rootScope.$broadcast('getCart', { callback: false} );

							// получаем список промокодов
							var codes_getted = Request.GetRequest({command: 'GET_PROMO_CODES', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
							if( codes_getted ){
								codes_getted.$promise.then(function(results) {
									console.log(results);
									if( results.promoPackList.length == 0 ){
										growl.error($scope.localization.codes.noResults, {ttl: -1} );
										$scope.contentLoaded = true;
										$scope.codesList = false;
										$scope.codesPack = false;
										angular.element('#content .preloader').hide();
									} else {
										$scope.codesPack = results.promoPackList;
										var codes_active = [];
										var codes_passive = [];
										$.each($scope.codesPack, function(key, pack) {
											var info = $scope.localization.codes.sinceTxt +" "+ pack.startTime +" "+ $scope.localization.codes.untilTxt +" "+ pack.endTime +", "+ $scope.localization.codes.discountTxt +" "+ pack.discountPercent +"%";
											if(pack.maxDiscountSum){
												info += ", "+ $scope.localization.codes.maxDiscountTxt +" "+ pack.maxDiscountSum +" "+ $scope.localization.currency;
											}
											if(pack.maxTickets){
												info += ", "+ $scope.localization.codes.maxTicketsTxt +" "+ pack.maxTickets +" "+ $scope.localization.unit;
											}
											if(pack.activeNow){
												$.each(pack.promoCodeList, function(key, code) {
													code.discount = pack.discountPercent;
													code.info = info;
													code.pack = pack.promoPackId;
													if(code.used || code.spent){
														code.active = false;
														codes_passive.push(code);
													} else {
														code.active = true;
														codes_active.push(code);
													}
												});
											} else {
												$.each(pack.promoCodeList, function(key, code) {
													code.active = false;
													code.discount = pack.discountPercent;
													code.info = info;
													code.pack = pack.promoPackId;
													codes_passive.push(code);
												});
											}
										});
										$scope.codesList = codes_active.concat(codes_passive);
									}
								});
								$scope.contentLoaded = true;
							}

						}
					});
				}

			}

			$scope.$watch('contentLoaded', function(){
				var grid = document.getElementById('grid');
				if( $scope.contentLoaded ){
					grid.style.height = 'auto';
					grid.style.overlow = 'visible';
					grid.style.opacity = 1;
				} else {
					grid.style.height = '0px';
					grid.style.overlow = 'hidden';
					grid.style.opacity = 0;
				}
			});

			$scope.OpenPack = function(packId){
				$.each($scope.codesPack, function(key, pack) {
					if(pack.promoPackId == packId){
						var html = '<div id = "pack-popup"><div class = "popup-title">'+ pack.name +'</div><div class = "popup-content">'+ pack.description + '</div></div>';
						$.fancybox.open(html);
					}
				});
			}

		});

	}

})();
