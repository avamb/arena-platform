(function() {
	
	'use strict';

	angular
		.module('bilpro').controller('bilBasket', bilBasket);

	function bilBasket($rootScope, $scope, $location, $localStorage, $interval, $timeout, $window, growl, Request) {
		// $resource, $window,

		$rootScope.$on('getCart', function(event, args){
			$scope.getCart(args.callback);
		});
		$scope.disabledBasketPromoCodes = true;
		$scope.getCart = function(callback){
			// проверяем есть ли что-то забронированное ранее
			var cart_getted = Request.GetRequest({command: 'GET_CART', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( cart_getted ){
				cart_getted.$promise.then(function(results) {
					console.log(results);
					if(results.resultCode == 101) {
						growl.error(results.description);
					} else if(results.resultCode == 0) {

						if ( $scope.config.isGood ) {
							$scope.localization.setSuccess1Appendix = $scope.localization.codes.goods.setSuccess1Appendix;
							$scope.localization.setSuccess2Appendix = $scope.localization.codes.goods.setSuccess2Appendix_goods;
							$scope.localization.emailPlaceholder = $scope.localization.settings.goods.emailPlaceholderTxt;
						} else {
							$scope.localization.setSuccess1Appendix = $scope.localization.codes.tickets.setSuccess1Appendix;
							$scope.localization.setSuccess2Appendix = $scope.localization.codes.tickets.setSuccess2Appendix;
							$scope.localization.emailPlaceholder = $scope.localization.settings.tickets.emailPlaceholderTxt;
						}

						$interval.cancel($scope.tickets.timeout.function);
						$scope.tickets.timeout.function = false;
						$scope.tickets.timeout.time = false;
						$scope.tickets.timeout.format = false;
						$scope.tickets.withPlace.data = [];
						$scope.tickets.withPlace.count = 0;

						for (var key_action in results.actionEventList) {
							if( results.actionEventList[key_action].fullNameRequired ){
								$scope.config.fullName.required = true;
							}
							if( results.actionEventList[key_action].phoneRequired ){
								$scope.config.phone.required = true;
							}
						}

						// заполняем предбронированными местами корзину
						if( typeof results.time != 'undefined' && results.time != 0 ){
							$scope.tickets.timeout.time = results.time;
							$scope.tickets.timeout.function = $interval(function() {
								$scope.tickets.timeout.time--;
								console.log($scope.tickets.timeout.time);
							}, 1000);

							// сохраняем количество билетов в корзине
							$scope.tickets.withPlace.data = results.actionEventList;
						}
						$scope.tickets.totalCharge = results.totalServiceCharge;
						$scope.tickets.totalSum = results.totalSum + results.totalServiceCharge;

						// обновляем корзину
						$scope.updateBasket();

						if( callback ){
							for (var key_venue in $scope.venueList) {
								// определяем видимость площадок
								$scope.venueList[key_venue].show = false;
								for (var key in $scope.tickets.withPlace.data) {
									if( $scope.venueList[key_venue].venueId == $scope.tickets.withPlace.data[key].venueId ){
										$scope.venueList[key_venue].show = true;
									}
									var stringDate = $scope.tickets.withPlace.data[key].day.split('.');
									$scope.tickets.withPlace.data[key].parsedDate = new Date(stringDate[2] +'.'+ stringDate[1] +'.'+ stringDate[0] +' '+ $scope.tickets.withPlace.data[key].time);
								}
							}
							$timeout(function(){
								$scope.fullBasket.loading = false;
							}, 1000);
						}

					}
				});
			}
		}

		$rootScope.$on('updateBasket', function(){
			$scope.updateBasket();
		});
		$scope.updateBasket = function() {
			// обновляем видимость и содержимое корзины
			$scope.miniBasket.count = 0;

			$scope.tickets.withPlace.count = 0;
			for (var key in $scope.tickets.withPlace.data) {
				$scope.tickets.withPlace.count += $scope.tickets.withPlace.data[key].seatList.length;
			}
			$scope.tickets.withoutPlace.count = 0;
			for (var key in $scope.tickets.withoutPlace.data) {
				$scope.tickets.withoutPlace.count += parseInt($scope.tickets.withoutPlace.data[key]);
			}
			$scope.miniBasket.count = $scope.tickets.withoutPlace.count + $scope.tickets.withPlace.count;

			console.log($scope.tickets);

			if( $scope.miniBasket.count == 0 ){
				$scope.miniBasket.show = false;
			} else {
				$scope.miniBasket.show = true;
			}

		}

		$scope.clearBusket = function() {
			// обновляем схему зала
			$rootScope.$broadcast('clearSheme');

			// и корзину
			$scope.tickets.withPlace.data = [];
			$scope.tickets.withPlace.count = 0;
			for (var key_cat in $scope.categories) {
				$scope.tickets.withoutPlace.data[$scope.categories[key_cat].ID] = 0;
			}
		}

		$scope.$watch('fullBasket.show', function() {
			// выводим корзину
			var class_ = document.documentElement.className;
			if( $scope.fullBasket.show ){

				var params = $location.search();
				$scope.localization.agreement = $scope.localization.basket.full.agreementPrefixTxt + params.agr + $scope.localization.basket.full.agreementAppendixTxt;

				document.documentElement.setAttribute("class", class_ + " basket-opened");
				$scope.fullBasket.loading = true;

				$scope.getCart(function(){
					for (var key_venue in $scope.venueList) {
						// определяем видимость площадок
						$scope.venueList[key_venue].show = false;
						for (var key in $scope.tickets.withPlace.data) {
							if( $scope.venueList[key_venue].venueId == $scope.tickets.withPlace.data[key].venueId ){
								$scope.venueList[key_venue].show = true;
							}
							var stringDate = $scope.tickets.withPlace.data[key].day.split('.');
							$scope.tickets.withPlace.data[key].parsedDate = new Date(stringDate[2] +'.'+ stringDate[1] +'.'+ stringDate[0] +' '+ $scope.tickets.withPlace.data[key].time);
						}
					}
					$timeout(function(){
						$scope.fullBasket.loading = false;
					}, 1000);
				});
			} else {
				document.documentElement.setAttribute("class", class_.replace(" basket-opened", ""));
			}
		});

		$rootScope.$on('openBasket', function(event, args){
			$scope.FillBusket();
		});
		$scope.FillBusket = function() {
// бронируем билеты в безместовой зоне, если они есть
			if( $scope.tickets.withoutPlace.count > 0 ){
				
				var bb_count = 0, bb_data = {};
				for (var bb_cat in $scope.tickets.withoutPlace.data) {
					if ($scope.tickets.withoutPlace.data[bb_cat] > 0) {
						bb_count++;
						bb_data[bb_cat] = $scope.tickets.withoutPlace.data[bb_cat];
					}
				}
				if (bb_count > 0) {
					var ticket_reserved, item;
					for (var bb_item in bb_data) {
						item = {};
						item[bb_item] = bb_data[bb_item];
						ticket_reserved = Request.GetRequest({
							command: 'RESERVATION',
							userId: $localStorage.userId,
							sessionId: $localStorage.sessionId,
							categoryQuantityMap: item,
							type: 'RESERVE',
							fid: $scope.config.fid,
							token: $scope.config.token,
							versionCode: $scope.config.versionCode
						});
						if( ticket_reserved ){
							ticket_reserved.$promise.then(function(results) {
								console.log(results);
								if(results.resultCode == 101 || results.resultCode != 0) {
									growl.error(results.description);
								} else if(results.resultCode == 0) {
									// обнуляем массив мест в безместовой зоне, он уже в корзине
									for (var key in $scope.tickets.withoutPlace.data) {
										$scope.tickets.withoutPlace.data[key] = 0;
										$scope.tickets.withoutPlace.count = 0;
									}
									for (var key_cat in $scope.categories) {
										$scope.categories[key_cat].count = 0;
									}
									$scope.fullBasket.show = true;
								}
							});	
						}
					}
				}
			} else {
				$scope.fullBasket.show = true;
			}
		}

		$scope.$watch('tickets.timeout.time', function() {
			// очищаем бронь
			if( $scope.tickets.timeout.time === 0 ){

				$interval.cancel($scope.tickets.timeout.function);
				$scope.clearBusket();
				$scope.updateBasket();

				// закрываем корзину
				$scope.tickets.timeout.format = false;
				$scope.fullBasket.show = false;
				growl.error($scope.localization.basket.full.clearedMsg);

			} else if( $scope.tickets.timeout.time ) {
				// выводим оставшееся время
				var min = Math.floor($scope.tickets.timeout.time / 60);
				var sec = $scope.tickets.timeout.time - min * 60;
				if( sec < 10 ) sec = '0' + sec;
				$scope.tickets.timeout.format = min +':'+ sec;
			}
		})

		$scope.findByAttributeValue = function(tagName, attribute, value) {
			var all = document.getElementsByTagName(tagName);
			for (var i = 0; i < all.length; i++) {
				if (all[i].getAttribute(attribute) == value) {
					return all[i];
				}
			}
		}

		$scope.UnreserveTicket = function(ticket) {
			var ticket_unreserved = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, seatList: [ticket.seatId], type: 'UN_RESERVE', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( ticket_unreserved ){
				ticket_unreserved.$promise.then(function(results) {
					console.log(results);
					if(results.resultCode == 101) {
						growl.error(results.description);
					} else if(results.resultCode == 0) {
						var element = $scope.findByAttributeValue("circle", "sbt:id", ticket.seatId);
						if( typeof(element) != 'undefined' ){
							var state = element.getAttribute("sbt:state");
							var class_ = element.getAttribute("class");
							element.removeAttribute("opacity");
							if (state == 1) {
								state = "2";
								element.setAttribute("class", class_ + " st4");
							} else {
								state = "1";
								element.setAttribute("class", class_.replace(" st4", ""));
							}
							element.setAttribute("sbt:state", state);
						}

						// обновляем содержимое корзины
						$scope.fullBasket.loading = true;
						$rootScope.$broadcast('getCart', { callback: true} );

					}
				});
			}
		}

		$scope.UnreserveAll = function() {
			// очищаем корзину
			var basket_cleared;
			basket_cleared = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, type: 'UN_RESERVE_ALL', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( basket_cleared ){
				basket_cleared.$promise.then(function(results) {
					console.log(results);
					if(results.resultCode == 101) {
						growl.error(results.description);
					} else if(results.resultCode == 0) {
						$interval.cancel($scope.tickets.timeout.function);
						$scope.tickets.timeout.function = false;
						$scope.tickets.timeout.time = false;
						$scope.tickets.timeout.format = false;
						$scope.clearBusket();
						$scope.updateBasket();
					}
				});
			}
		}

		$scope.CreateOrder = function() {
			if( typeof $scope.basketPromoCodes != 'undefined' && $scope.basketPromoCodes != '' ){
				// добавляем промокоды
				$scope.SetBasketPromoCodes();
			} else {
				// создаем заказ
				var order_created = Request.GetRequest({command: 'CREATE_ORDER', phone: $scope.config.phone.value, fullName: $scope.config.fullName.value, userId: $localStorage.userId, sessionId: $localStorage.sessionId, successUrl: $scope.config.successUrl, failUrl: $scope.config.failUrl, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
				if( order_created ){
					order_created.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							if( results.formUrl != '' ){
								$window.location.href = results.formUrl;
							} else {
								$window.location.href = $scope.config.successUrl;
							}
						}
					});
				}
			}
		}

		// функции для работы с промокодами
		$scope.SetBasketPromoCodes = function(){
			var basketPromoCodes = $scope.basketPromoCodes.split(' ');
			var basketPromoCodes_added = Request.GetRequest({command: 'ADD_PROMO_CODES', userId: $localStorage.userId, promoCodeList: basketPromoCodes, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			if( basketPromoCodes_added ){
				basketPromoCodes_added.$promise.then(function(results) {
					console.log(results);
					if(results.resultCode == 101) {
						growl.error(results.description);
					} else if(results.resultCode == 0) {

						if( results.newPromoCodeList.length > 0 ){
							$scope.getCart();
							if( results.newPromoCodeList.length == 1 ){
								var message = $scope.localization.codes.setSuccess1Prefix + results.newPromoCodeList[0];
								if ( $scope.config.isGood ) {
									message += $scope.localization.codes.goods.setSuccess1Appendix;
								} else {
									message += $scope.localization.codes.tickets.setSuccess1Appendix;
								}
								growl.success(message, {ttl: 10000} );
							} else {
								var message = $scope.localization.codes.setSuccess2Prefix + results.newPromoCodeList[0];
								if ( $scope.config.isGood ) {
									message += $scope.localization.codes.goods.setSuccess2Appendix;
								} else {
									message += $scope.localization.codes.tickets.setSuccess2Appendix;
								}
							}
						} else {
							if( results.errorPromoCodeList.length == 1 ){
								growl.error($scope.localization.codes.setErrorMsg1);
							} else {
								growl.error($scope.localization.codes.setErrorMsg2);
							}
						}
						$scope.basketPromoCodes = '';

					}
				});
			}
		}

		$scope.$watch('basketPromoCodes', function() {
			if( $scope.basketPromoCodes ){
				$scope.disabledBasketPromoCodes = false;
			} else {
				$scope.disabledBasketPromoCodes = true;
			}
		});

	}

})();