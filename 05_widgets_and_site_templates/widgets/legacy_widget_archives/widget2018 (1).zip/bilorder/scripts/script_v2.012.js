(function() {
	
	'use strict';

	// $(window).on('load', function(){

	// 	var hammertime = new Hammer(document.body);
	// 	hammertime.get('pinch').set({ enable: true });
	// 	hammertime.on('pinchend pinchcancel', function(ev) {
	// 		setTimeout(function(){
	// 			$('header').css('transform', 'scale('+ 1 / ev.scale +')');
	// 		}, 500);
	// 	});

	// });

	var initialW;
	var initialH;

	function setScale(scale) {
		console.log(scale);
		$('#sheme svg').css({
			'width': scale * 100 + '%'
		});
	}

	angular
		.module('bilpro', ['angular-growl', 'ngAnimate', 'ngResource', 'ngStorage', 'ngSanitize'])
		.factory('Request', Request)
		.directive('masked', masked)
		.directive('numbersOnly', numbersOnly)
		.config(['growlProvider', function(growlProvider) {
			growlProvider.globalTimeToLive(5000);
		}])
		.controller('bilController', bilController);

	function masked() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
				elm.mask(attrs.format, {
					completed: function() { 
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});
			}
		}
	}

	function numbersOnly() {
		return {
			require: 'ngModel',
			link: function(scope, element, attrs, modelCtrl) {
				modelCtrl.$parsers.push(function(inputValue) {
					if (inputValue == undefined) return ''
					var onlyNumeric = inputValue.replace(/[^0-9]/g, '');
					if (onlyNumeric != inputValue) {
						modelCtrl.$setViewValue(onlyNumeric);
						modelCtrl.$render();
					}
					return onlyNumeric;
				});
			}
		}
	}

	function Request($resource, $location) {

		var requestUrl;
		var params = $location.search();
		switch (params.zone) {
			case 'real':
			requestUrl = 'https://api.bil24.pro:443/json';
			break;
			case 'test':
			requestUrl = 'https://api.bil24.pro:1240/json';
			break;
			default:
			requestUrl = 'https://api.bil24.pro:'+ params.zone +'/json';
			break;
		}

		return $resource(requestUrl, {
			fid: '@fid',
			token: '@token',
			versionCode: '@versionCode',
			command: '@command',
			phone: '@phone',
			fullName: '@fullName',
			categoryQuantityMap: '@categoryQuantityMap',
			code: '@code',
			email: '@email',
			userId: '@userId',
			seatList: '@seatList',
			sessionId: '@sessionId',
			type: '@type'
		}, {
			GetRequest: {
				method: 'POST',
				isArray: false
			},
			GetLocalization: {
				method: 'GET',
				isArray: false,
				url: '/bilorder/localization/:local'
			}
		});
	}

	function bilController($rootScope, $scope, $location, $localStorage, $resource, $interval, $timeout, growl, Request) {

		$scope.config = {
			action: {
				name: false,
				description: false,
				venue: false
			},
			email: {
				disabled: true
			},
			isGood: false,
			venue: {
				ID: false,
				show: false
			},
			month: {
				ID: false,
				show: false
			},
			day: {
				ID: false,
				show: false
			},
			time: {
				ID: false,
				show: false
			},
			sheme: {
				url: false,
				loading: false,
				show: false
			},
			zoom: false,
			fullName: {
				required: false,
				value: ''
			},
			phone: {
				required: false,
				value: ''
			},
			noResults: false,
		};
		$scope.tickets = {
			timeout: {
				function: false,
				time: false,
				format: false
			},
			withPlace: {
				data: [],
				count: 0,
				show: false,
				noResults: false
			},
			withoutPlace: {
				data: {},
				count: 0,
				show: false
			},
			totalCharge: 0,
			totalSum: 0
		};
		$scope.miniBasket = {
			count: 0,
			show: false
		};
		$scope.fullBasket = {
			filled: false,
			loading: false,
			show: false
		}


		var params = $location.search();
		var local;
		// в первую очередь определяем язык и получаем локализацию
		if ( params.lng == 'ru' ) {
			local = 'ru_RU.json';
		} else {
			local = 'en_EN.json';
		}
		
		if ( params.goods == 'true' ) {
			$scope.config.isGood = true;
		}

		Request.GetLocalization({local: local}).$promise.then(function(result) {
			console.log(result);
			$scope.localization = result;

			if ( $scope.config.isGood ) {
				$scope.localization.available = $scope.localization.event.goods.availableTxt;
				$scope.localization.setSuccess1Appendix = $scope.localization.codes.goods.setSuccess1Appendix;
				$scope.localization.setSuccess2Appendix = $scope.localization.codes.goods.setSuccess2Appendix_goods;
				$scope.localization.emailPlaceholder = $scope.localization.settings.goods.emailPlaceholderTxt;
				$scope.localization.withPlace = $scope.localization.event.goods.withPlaceTxt;
				$scope.localization.withoutPlace = $scope.localization.event.goods.withoutPlaceTxt;
				$scope.localization.noPlace = $scope.localization.event.goods.noPlaceTxt;
			} else {
				$scope.localization.available = $scope.localization.event.tickets.availableTxt;
				$scope.localization.setSuccess1Appendix = $scope.localization.codes.tickets.setSuccess1Appendix;
				$scope.localization.setSuccess2Appendix = $scope.localization.codes.tickets.setSuccess2Appendix;
				$scope.localization.emailPlaceholder = $scope.localization.settings.tickets.emailPlaceholderTxt;
				$scope.localization.withPlace = $scope.localization.event.tickets.withPlaceTxt;
				$scope.localization.withoutPlace = $scope.localization.event.tickets.withoutPlaceTxt;
				$scope.localization.noPlace = $scope.localization.event.tickets.noPlaceTxt;
			}

			// получив локализации, проверяем все ли параметры у нас есть
			$scope.config.versionCode = '1.0';
			if ( typeof params.frontendId != 'undefined') {
				$scope.config.fid = params.frontendId;
			}
			if ( typeof params.token != 'undefined') {
				$scope.config.token = params.token;
			}
			if ( typeof params.id != 'undefined') {
				$scope.config.actionId = params.id;
			}
			if ( typeof params.cityId != 'undefined') {
				$scope.config.cityId = params.cityId;
			}
			if ( typeof params.success != 'undefined' && params.success != 'appsuccess' ) {
				$scope.config.successUrl = params.success;
			} else {
				$scope.config.successUrl = 'http://bilw.ru/TAC/pay_s.html';
			}
			if ( typeof params.fail != 'undefined' && params.fail != 'appfail' ) {
				$scope.config.failUrl = params.fail;
			} else {
				$scope.config.failUrl = 'http://bilw.ru/TAC/pay_f.html';
			}
			$scope.config.zone = params.zone;
			$scope.config.lng = params.lng;

			// проверяем сохранены ли доступы в локальном хранилище
			var get_access = false;
			if( typeof $localStorage.userId == 'undefined' || typeof $localStorage.sessionId == 'undefined' ){
				// в локальном хранилище было пусто, получаем новые доступы
				get_access = Request.GetRequest({command: 'AUTH', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
			} else {
				get_access = true;
			}

			// проверяем актуальность сохраненных доступов
			var check_access = false;
			if( get_access ){
				if( typeof get_access == 'object' ){
					get_access.$promise.then(function(results) {
						console.log(results);
						// если ошибок нет - сохраняем полученные доступы в куках
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							$localStorage.userId = results.userId;
							$localStorage.sessionId = results.sessionId;
						}
					});
				}
				check_access = Request.GetRequest({command: 'AUTH', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});

				var email_getted = false;
				var actions_getted = false;
				$scope.disabledPromoCodes = true;
				$scope.showConfirm = false;
				$scope.showPromoCodes = false;
				if( check_access ){
					check_access.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {
							// проверяем почту
							email_getted = Request.GetRequest({command: 'GET_EMAIL', userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
							if( email_getted ){
								email_getted.$promise.then(function(results) {
									console.log(results);
									if(results.resultCode == 101) {
										growl.error(results.description);
									} else if( results.resultCode == 0 && results.email != '' ){
										$scope.config.email.disabled = false;
										$scope.oldEmail = $scope.email = results.email;
										$scope.showPromoCodes = true;
									}
								});
							}

							$scope.eventMonthList = [];
							$scope.eventDayList = [];
							$scope.eventTimeList = [];
							actions_getted = Request.GetRequest({command: 'GET_ACTION_EXT', cityId: $scope.config.cityId, actionId: $scope.config.actionId, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
							if( actions_getted ){
								actions_getted.$promise.then(function(results) {
									console.log(results);
									if(results.resultCode == 101) {
										growl.error(results.description);
									} else if(results.resultCode == 0) {

										// заполняем шапку виджета
										$scope.config.action.name = results.action.actionName;
										$scope.config.action.description = results.action.fullActionName;

										if( results.action.venueList == 0 ){
											$scope.config.noResults = true;
											$scope.contentLoaded = true;
										} else {

											// площадки в любом случае выводим все
											$scope.venueList = results.action.venueList;
											if( results.action.venueList.length == 1 ){

												// если площадка одна - выбираем единственную площадку
												$scope.SelectVenue(results.action.venueList[0].venueId);

											} else {
												// выводим выбор площадок
												$scope.config.venue.show = true;

												if( typeof params.venueId != 'undefined' && params.venueId != 'false' ){
													// активной делаем ту, что указана в параметрах урла
													$scope.SelectVenue(params.venueId);
												}
											}
											// заполняем площадку в шапке виджета
											if( $scope.config.venue.ID && results.action.venueList.length == 1 ){
												for (var key_venue in results.action.venueList) {
													if( results.action.venueList[key_venue].venueId == $scope.config.venue.ID ){
														$scope.config.action.venue = results.action.venueList[key_venue].venueName;
													}
												}											
											}

											// добавляем недостающие данные
											$scope.addMonthValue();
											// $scope.addDayValue();
											// $scope.addTimeValue();
											$scope.config.venue.show = true; // убрать

											// проверяем есть ли что-то забронированное ранее
											$rootScope.$broadcast('getCart', { callback: false} );

											// заполним конфиг пустыми массивами безместовых зон
											for (var key_venue in results.action.venueList) {
												for (var key_list in results.action.venueList[key_venue].actionEventList) {

													for (var key_limit in results.action.venueList[key_venue].actionEventList[key_list].categoryLimitList) {
														for (var key in results.action.venueList[key_venue].actionEventList[key_list].categoryLimitList[key_limit].categoryList) {

															$scope.tickets.withoutPlace.data[results.action.venueList[key_venue].actionEventList[key_list].categoryLimitList[key_limit].categoryList[key].categoryPriceId] = 0;			
														}
													}
												}
											}

											$scope.contentLoaded = true;
										}
									}
								});
							}

						}
					});
				}

			}

			$scope.$watch('eventLimit', function(){
				if( typeof $scope.eventLimit != 'undefined' ){
					$scope.categories = [];
					for (var key_limit in $scope.eventLimit) {
						for (var key_cat in $scope.eventLimit[key_limit].categoryList) {
							var category = {};
							category.ID = $scope.eventLimit[key_limit].categoryList[key_cat].categoryPriceId;
							category.name = $scope.eventLimit[key_limit].categoryList[key_cat].categoryPriceName;
							category.price = $scope.eventLimit[key_limit].categoryList[key_cat].price;
							category.count = $scope.tickets.withoutPlace.data[category.ID];
							/* v1.1 */
							category.result = category.availability = $scope.eventLimit[key_limit].categoryList[key_cat].availability;
							/* /v1.1 */
							$scope.categories.push(category);
							$scope.tickets.withoutPlace.show = true;
						}
					}
				}
			});

			// функции для работы со схемой зала
			/* v1.1 */
			var panZoom;
			$scope.$watch('config.sheme.url', function(){
				if( $scope.config.sheme.url ){
					var sheme_getted = $resource($scope.config.sheme.url +'&rnd=' + Math.random(), {}, {
						get: {
							method: 'get',
							transformResponse: function (response) {
								return {html: response};
							}
						}
					}).get();
					if( sheme_getted ){
						sheme_getted.$promise.then(function(results) {
							console.log(results);
							document.querySelector('#sheme').innerHTML = results.html;
							var sheme = document.querySelector('#sheme').getElementsByTagName('svg')[0];

							var height, width, newWidth, newHeight;
							height = sheme.getAttribute("height");
							width = sheme.getAttribute("width");
							newWidth = document.querySelector('#sheme').offsetWidth;
							newHeight = newWidth * height / width;
							if( document.documentElement.className.indexOf('no-touchevents') != -1 ){
								sheme.setAttribute("width", newWidth);
								sheme.setAttribute("height", newHeight);
								panZoom = svgPanZoom(sheme, {
									center: false,
									controlIconsEnabled: true,
									maxZoom: 50,
									mouseWheelZoomEnabled: false,
									zoomScaleSensitivity: .5
								});
							} else {
								document.querySelector('#sheme').style.height = newHeight + 'px';
							}

							$scope.config.sheme.loading = false;
							$scope.config.sheme.show = true;
							$scope.shemeInit();

						});
					}
				}
			});
			/* /v1.1 */
			// $scope.animate = function(elem,style,unit,from,to,time,prop) {
			// 	if( !elem) return;
			// 	var start = new Date().getTime(),
			// 	timer = setInterval(function() {
			// 		var step = Math.min(1,(new Date().getTime()-start)/time);
			// 		if (prop) {
			// 			elem[style] = (from+step*(to-from))+unit;
			// 		} else {
			// 			elem.style[style] = (from+step*(to-from))+unit;
			// 		}
			// 		if( step == 1) clearInterval(timer);
			// 	},25);
			// 	elem.style[style] = from+unit;
			// }

			$scope.shemeInit = function() {

				$scope.config.zoom = 1;
				var mas = document.getElementsByTagName('*');
				var sbtOwner = 0;
				for(var i = 0; i < mas.length; i++) {
					//если это не место, продолжим перебирать элементы
					if (!mas[i].hasAttribute("sbt:seat")) continue;

					//статус места
					var state = mas[i].getAttribute("sbt:state");

					//установим слушатель только если место свободное или предбронировано мной
					if (state == 1 || (state == 2 && mas[i].hasAttribute("sbt:owner"))) {
						new Hammer(mas[i]).on("tap", function(ev) {
							$scope.addClickHandler(ev.target);
							$timeout(function(){
								var element = ev.target;
								var elementId = element.getAttribute("id");
								var state = element.getAttribute("sbt:state");
								if( state == 1 ){
									element.removeAttribute("opacity");
								}
							}, 10000);
						});
					}
				}

				// заполняем цены в легенде
				document.querySelector('.placementLegend-wrapper').innerHTML = '';
				var categories = document.querySelector('#sheme svg').getElementsByTagName('sbt:category');
				for (var i = 0; i < categories.length; i++) {
					var color = categories[i].getAttribute("sbt:color");
					var price = categories[i].getAttribute("sbt:price");
					var used = categories[i].getAttribute("sbt:used");
					if( used == 1){
						var legendElem = document.createElement('div');
						legendElem.className = 'placementLegend-item';
						legendElem.innerHTML = '<i style = "background-color: '+ color +'"></i> - '+ price +  '&nbsp;' + $scope.localization.currency;
						document.querySelector('.placementLegend-wrapper').appendChild(legendElem);
						console.log(categories[i]);
					}
				}

			}
			$rootScope.$on('clearSheme', function(){
				if( $scope.config.sheme.url ){
					var mas = document.getElementsByTagName('*');
					for(var i = 0; i < mas.length; i++) {
						if (!mas[i].hasAttribute("sbt:seat")) continue;
						var state = mas[i].getAttribute("sbt:state");
						if (state == 2) {
							var class_ = mas[i].getAttribute("class");
							mas[i].setAttribute("class", class_.replace(" st4", ""));
							mas[i].setAttribute("sbt:state", 1);
						}
					}
				}
			});
			/* v1.1 */
			$scope.zoomIn = function() {
				if( $scope.config.zoom < 30){
					console.log('zoomIn');
					$scope.config.zoom++;
				}
			}
			$scope.zoomOut = function() {
				if( $scope.config.zoom > 0){
					console.log('zoomOut');
					$scope.config.zoom--;
				}
			}
			$scope.$watch('config.zoom', function() {
				if( $scope.config.zoom ){
					if( document.documentElement.className.indexOf('no-touchevents') == -1 ){
						setScale($scope.config.zoom);
					} else if( typeof panZoom != 'undefined' ) {
						panZoom.zoom($scope.config.zoom);
					}
					console.log($scope.config.zoom);
				}
			});
			/* /v1.1 */

			// местовая зона
			$scope.addClickHandler = function(element) {
				console.log(element);
				var elementId = element.getAttribute("id");  //id элемента
				var seatId = element.getAttribute("sbt:id");  //id места в БС
				var state = element.getAttribute("sbt:state");//статус места
				var cat = element.getAttribute("sbt:cat");    //категория, описанная в svg документе
				var categoryName = $scope.findByAttributeValue("sbt:category", "sbt:index", cat).getAttribute("sbt:name"); //имя категории
				var categoryPrice = $scope.findByAttributeValue("sbt:category", "sbt:index", cat).getAttribute("sbt:price"); //цена категории
				var row = element.parentElement.getAttribute("sbt:row");    //номер ряда
				var seat = element.getAttribute("sbt:seat");                //номер места в ряду
				var sector = element.parentElement.getAttribute("sbt:sect");//название сектора

				//если уже нажимали на место и результат еще не вернулся
				if (element.hasAttribute("opacity")) return;
				element.setAttribute("opacity", "0.2");
				var class_ = element.getAttribute("class");
				if (state == 1) {
					var ticket_reserved = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, seatList: [seatId], type: 'RESERVE_BY_PLACE', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( ticket_reserved ){
						ticket_reserved.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
								element.removeAttribute("opacity");

								jQuery('html, body').animate({
									scrollTop: jQuery(".email-get").offset().top - 200
								}, 1000);
								jQuery(".email-get input[type='email']").focus();
								
							} else if(results.resultCode == 0) {
								$scope.toggleReserve(elementId);

								// обновляем содержимое корзины
								$rootScope.$broadcast('getCart', { callback: false} );
							}
						});
					}
				} else {
					var ticket_unreserved = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, seatList: [seatId], type: 'UN_RESERVE', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( ticket_unreserved ){
						ticket_unreserved.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
							} else if(results.resultCode == 0) {
								$scope.toggleReserve(elementId);

								// обновляем содержимое корзины
								$rootScope.$broadcast('getCart', { callback: false} );

							}
						});
					}
				}

			}

			$scope.findByAttributeValue = function(tagName, attribute, value) {
				var all = document.getElementsByTagName(tagName);
				for (var i = 0; i < all.length; i++) {
					if (all[i].getAttribute(attribute) == value) {
						return all[i];
					}
				}
			}

			$scope.toggleReserve = function(elementId) {
				console.log(elementId);
				var element = document.getElementById(elementId);
				var state = element.getAttribute("sbt:state");
				var class_ = element.getAttribute("class");
				element.removeAttribute("opacity");
				if (state == 1) {
					state = "2";
					element.setAttribute("class", class_ + " st4");
				} else {
					state = "1";
					element.setAttribute("class", class_.replace(" st4", ""));
				}
				element.setAttribute("sbt:state", state);
			}

			// безместовая зона
			$scope.ChangeCount = function(ID, action) {
				if( !$scope.config.email.disabled ){
					for (var key_cat in $scope.categories) {
						if( $scope.categories[key_cat].ID == ID){
							/* v1.1 */
							if(action == 'plus' && $scope.categories[key_cat].count < $scope.categories[key_cat].availability){
							/* /v1.1 */
								$scope.categories[key_cat].count++;
							}
							if(action == 'minus' && $scope.categories[key_cat].count > 0){
								$scope.categories[key_cat].count--;
							}
							$scope.WithoutPlaceReserve(ID, $scope.categories[key_cat].count);
							$scope.tickets.withoutPlace.data[ID] = $scope.categories[key_cat].count;

							/* v1.1 */
							for(var key_category in $scope.categories){
								console.log($scope.categories[key_category]);
								for (var key_limit in $scope.eventLimit) {
									$scope.updateAvailability($scope.categories[key_category], $scope.eventLimit[key_limit].categoryList)
								}
							}
							/* /v1.1 */
						}
					}
				} else {
					growl.error($scope.localization.setEmailMsg);
				}
			}
			$scope.WithoutPlaceReserve = function(ID, count) {
				for (var key in $scope.categories) {
					if( $scope.categories[key].ID == ID){
						/* v1.1 */
						if( $scope.categories[key].count == '' || $scope.categories[key].count < 0 ){
							$scope.categories[key].count = 0;
						} else if( $scope.categories[key].count > $scope.categories[key].availability ){
							$scope.categories[key].count = $scope.categories[key].availability;
						} else {
							$scope.categories[key].count = parseInt(count);
						}
						/* /v1.1 */
					}
				}
				// проверяем на ограничения
				var remainder = false;
				var limits = {};
				var total = 0;
				for (var key_limit in $scope.eventLimit) {
					for (var key_list in $scope.eventLimit[key_limit].categoryList) {
						if( ID == $scope.eventLimit[key_limit].categoryList[key_list].categoryPriceId && typeof $scope.eventLimit[key_limit].remainder != 'undefined' ){
							remainder = $scope.eventLimit[key_limit].remainder;
							limits = $scope.eventLimit[key_limit].categoryList;
						}
					}
				}
				if( remainder ){
					for (var key_limit in limits) {
						for (var key_cat in $scope.categories) {
							if($scope.categories[key_cat].ID == limits[key_limit].categoryPriceId){
								total += $scope.categories[key_cat].count;
							}
						}
					}
					var delta = total - remainder;
					if( delta > 0 ){
						for (var key_cat in $scope.categories) {
							if( $scope.categories[key_cat].ID == ID){
								$scope.categories[key_cat].count -= delta;
							}
						}
					}
				}
				for (var key_category in $scope.categories) {
					$scope.tickets.withoutPlace.data[$scope.categories[key_category].ID] = $scope.categories[key_category].count;
				}

				/* v1.1 */
				for (var key_category in $scope.categories) {
					console.log($scope.categories[key_category]);
					for (var key_limit in $scope.eventLimit) {
						$scope.updateAvailability($scope.categories[key_category], $scope.eventLimit[key_limit].categoryList)
					}
				}
				/* /v1.1 */

				$rootScope.$broadcast('updateBasket');
			}
			/* v1.1 */
			$scope.updateAvailability = function(elem, array) {
				var result = false;
				for(var key_limit in array){
					if( elem.ID == array[key_limit].categoryPriceId ){
						result = true;
					}
				}
				if(result){
					var sum = 0;
					for(var key_limit in array){
						for(var key_data in $scope.tickets.withoutPlace.data){
							if(array[key_limit].categoryPriceId == key_data){
								sum += $scope.tickets.withoutPlace.data[key_data];
							}
						}
					}
					elem.result = elem.availability - sum;
				}
			}
			/* /v1.1 */

			// функции для работы с почтой
			$scope.SetEmail = function(){
				if( $scope.email == $scope.oldEmail ){
					growl.error($scope.localization.settings.emailConfirmedYetMsg);
				} else {
					var email_setted = Request.GetRequest({command: 'BIND_EMAIL', email: $scope.email, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( email_setted ){
						email_setted.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
							} else if(results.resultCode == 0) {
								$scope.emailConfirmMsg = $scope.localization.settings.emailConfirmSendMsg;
								$scope.showConfirm = true;
							}
						});
					}
				}
			}
			$scope.ConfirmEmail = function(){
				var email_confirmed = Request.GetRequest({command: 'CONFIRM_EMAIL', code: $scope.code, userId: $localStorage.userId, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
				if( email_confirmed ){
					email_confirmed.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode != 0) {
							growl.error(results.description);
						} else {
							$scope.oldEmail = $scope.email = results.email;
							growl.success($scope.localization.settings.emailConfirmSuccessMsg);
							$scope.showConfirm = false;
							$scope.showPromoCodes = true;
							// проверяем соответсвуют ли сохраненные userId и sessionId пришедшим в ответе
							if( $localStorage.userId != results.userId || $localStorage.sessionId != results.sessionId ){
								$localStorage.userId = results.userId;
								$localStorage.sessionId = results.sessionId;
							}
							$scope.config.email.disabled = false;

						}
					});
				}
			}

			// функции для работы с промокодами
			$scope.SetPromoCodes = function(){
				var promoCodes = $scope.promoCodes.split(' ');
				var promoCodes_added = Request.GetRequest({command: 'ADD_PROMO_CODES', userId: $localStorage.userId, promoCodeList: promoCodes, sessionId: $localStorage.sessionId, fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
				if( promoCodes_added ){
					promoCodes_added.$promise.then(function(results) {
						console.log(results);
						if(results.resultCode == 101) {
							growl.error(results.description);
						} else if(results.resultCode == 0) {

							if( results.newPromoCodeList.length > 0 ){
								if( results.newPromoCodeList.length == 1 ){
									growl.success( $scope.localization.codes.setSuccess1Prefix + results.newPromoCodeList[0] + $scope.localization.setSuccess1Appendix, {ttl: 10000} );
								} else {
									growl.success( $scope.localization.codes.setSuccess2Prefix +' '+ results.newPromoCodeList.join(', ') + $scope.localization.setSuccess2Appendix, {ttl: 10000} );
								}
							} else {
								if( results.errorPromoCodeList.length == 1 ){
									growl.error($scope.localization.codes.setErrorMsg1);
								} else {
									growl.error($scope.localization.codes.setErrorMsg2);
								}
							}

							$scope.promoCodes = '';

						}
					});
				}
			}

			$scope.$watch('promoCodes', function() {
				if( $scope.promoCodes ){
					$scope.disabledPromoCodes = false;
				} else {
					$scope.disabledPromoCodes = true;
				}
			});

			$scope.$watch('config.sheme.loading', function() {
				if( $scope.config.sheme.loading ){
					$timeout(function() {
						var offsetTop = document.querySelector(".placement").offsetTop - 10;
						window.scrollTo(0, offsetTop, 'smooth');
					}, 0);
				}
			});

			/* первичная обработка */
			$scope.SelectVenue = function(id) {
				if( $scope.config.venue.ID != id ){
					// задаем новые значения площадки
					$scope.config.venue.ID = id;

					// подчищаем остальное, зависящее от площадки
					$scope.ResetMonth();
					$scope.ResetDay();
					$scope.ResetTime();
					$scope.ResetSheme();

					// площадка выбрана, получаем инфу по сеансам
					for (var key in $scope.venueList) {
						if($scope.venueList[key].venueId == $scope.config.venue.ID){
							$scope.eventList = $scope.venueList[key].actionEventList;
						}
					}
					var month_tmp = [];
					for (var key in $scope.eventList) {
						var date = $scope.eventList[key].day.split('.');
						if( month_tmp.indexOf(date[1]) == -1 ){
							month_tmp.push(date[1]);
						}
					}
					for (var key in month_tmp) {
						var month = [];
						month.monthId = month_tmp[key];
						month.monthName = $scope.localization[month_tmp[key]];
						$scope.eventMonthList.push(month);
					}

					if($scope.eventMonthList.length == 1){

						// месяц один, выбираем его
						$scope.SelectMonth($scope.eventMonthList[0].monthId);

					} else if( !$scope.config.month.show ){
						$scope.config.month.show = true;
					}

					// добавляем недостающие данные
					$scope.addDayValue();
					$scope.addTimeValue();

				}

			};

			$scope.SelectMonth = function(id) {
				if( $scope.config.month.ID != id ){
					// задаем новые значения месяца
					$scope.config.month.ID = id;

					// подчищаем остальное, зависящее от месяца
					$scope.ResetDay();
					$scope.ResetTime();
					$scope.ResetSheme();

					// месяц выбран, получаем инфу по дням
					for (var key in $scope.eventList) {
						var date = $scope.eventList[key].day.split('.');
						var dayObject = moment( $scope.eventList[key].day, 'DD.MM.YYYY' );
						var day = {};
						day.ID = dayObject.dayOfYear();
						day.name = date[0] + ' ' + $scope.localization.days[dayObject.weekday()];

						if($scope.config.month.ID == date[1]){
							var isSetYet = false;
							for (var key_day in $scope.eventDayList) {
								if( $scope.eventDayList[key_day].ID == day.ID ){
									isSetYet = true;
								}
							}
							if( !isSetYet ){
								$scope.eventDayList.push(day);
							}
						}
					}

					if($scope.eventDayList.length == 1){
						// день один, выбираем его
						$scope.SelectDay($scope.eventDayList[0].ID);
					}
					if($scope.eventMonthList.length > 1 || $scope.eventDayList.length > 1){
						$scope.config.day.show = true;
					}

					// добавляем недостающие данные
					$scope.addTimeValue();

				}

			};
			$scope.ResetMonth = function() {
				$scope.eventMonthList = [];
				$scope.config.month.ID = false;
				$scope.config.month.show = false;
			}

			$scope.SelectDay = function(day) {
				if( $scope.config.day.ID != day ){
					// задаем новые значения дня
					$scope.config.day.ID = day;

					// подчищаем остальное, зависящее от дня
					$scope.ResetTime();
					$scope.ResetSheme();

					// день выбран, получаем время сеансов
					for (var key in $scope.eventList) {
						var date = $scope.eventList[key].day.split('.');
						var dayObject = moment( $scope.eventList[key].day, 'DD.MM.YYYY' );
						if( $scope.config.day.ID == dayObject.dayOfYear() ){
							var time = [];
							time.timeId = $scope.eventList[key].actionEventId;
							time.timeValue = $scope.eventList[key].time;
							$scope.eventTimeList.push(time);
						}
					}

					if($scope.eventTimeList.length == 1){
						// время одно, выбираем его
						$scope.SelectTime($scope.eventTimeList[0].timeId);
					} else if( !$scope.config.time.show ){
						$scope.config.time.show = true;
					}
				}

			};
			$scope.ResetDay = function() {
				$scope.eventDayList = [];
				$scope.config.day.ID = false;
				$scope.config.day.show = false;
			}

			$scope.SelectTime = function(id) {

				if( $scope.config.time.ID != id ){

					// задаем новое значение времени
					$scope.config.time.ID = id;

					$scope.ResetSheme();

					// время выбрано, выдаем схему зала
					for (var key in $scope.eventList) {
						if( $scope.eventList[key].actionEventId == $scope.config.time.ID ){

							// определяем схему зала
							if( $scope.eventList[key].categoryLimitList.length == 0 ){
								if( typeof $scope.eventList[key].placementUrl != 'undefined' ) {
									$scope.config.sheme.url = $scope.eventList[key].placementUrl;
									$scope.config.sheme.loading = true;
								} else {
									$scope.tickets.withPlace.noResult = true;
									$scope.categories = [];
									$scope.eventLimit = false;
								}
							} else {
								if( typeof $scope.eventList[key].placementUrl == 'undefined' ) {
									$scope.tickets.withPlace.noResult = false;
									$scope.eventLimit = $scope.eventList[key].categoryLimitList;
								} else {
									$scope.config.sheme.url = $scope.eventList[key].placementUrl;
									$scope.config.sheme.loading = true;
									$scope.eventLimit = $scope.eventList[key].categoryLimitList;
								}
							}

							// определяем видимость заголовков
							if( $scope.eventList[key].categoryLimitList.length > 0 && typeof $scope.eventList[key].placementUrl != 'undefined' ){
								$scope.tickets.withPlace.show = true;
								$scope.tickets.withoutPlace.show = true;
							} else if( typeof $scope.eventList[key].placementUrl == 'undefined' ) {
								$scope.tickets.withoutPlace.show = true;
							}

						}
					}

				}
			};
			$scope.ResetTime = function() {
				$scope.eventTimeList = [];
				$scope.config.time.ID = false;
				$scope.config.time.show = false;
			}
			$scope.ResetSheme = function() {
				document.getElementById('sheme').innerHTML = '';
				$scope.config.sheme.url = false;
				$scope.config.sheme.loading = false;
				$scope.config.sheme.show = false;
				$scope.tickets.withPlace.show = false;
				$scope.tickets.withoutPlace.show = false;
			}

			$scope.addMonthValue = function() {

				var months = [];
				for( var key in $scope.venueList ) {

					if( $scope.venueList[key].venueId == $scope.config.venue.ID ){

						for (var key_list in $scope.venueList[key].actionEventList) {

							var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
							if( $.inArray(date[1], months) == -1 ){
								months.push( date[1]);
							}

						}

						if( months.length == 1 && !$scope.config.isGood ) {

							var month = $scope.localization[ months[0] ];
							if( $scope.venueList[key].venueName.indexOf(month) == -1 ){
								$scope.venueList[key].venueName += ', ' + month;
							}

						}

					}

				}

			}

			$scope.addDayValue = function() {

				if( $scope.eventMonthList.length == 1 ){

					for( var key_month in $scope.eventMonthList ) {

						var days = [];
						for( var key in $scope.venueList ) {

							if( $scope.venueList[key].venueId == $scope.config.venue.ID ) {

								for (var key_list in $scope.venueList[key].actionEventList) {

									var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
									if( $scope.eventMonthList[key_month].monthId == date[1] && $.inArray(date[0], days) == -1 ){
										days.push(date[0]);
									}

								}

								for (var key_list in $scope.venueList[key].actionEventList) {

									var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
									if( $scope.eventMonthList[key_month].monthId == date[1] && days.length == 1 ) {

										var dayObject = moment( $scope.venueList[key].actionEventList[key_list].day, 'DD.MM.YYYY' );
										var day = date[0] + ' ' + $scope.localization.days[dayObject.weekday()];
										if( $scope.eventMonthList[key_month].monthName.indexOf(day) == -1 ){
											$scope.eventMonthList[key_month].monthName += ' ' + day;
										}

										if( $scope.venueList.length == 1 ) {

											if( $scope.venueList[key].venueName.indexOf(day) == -1 && !$scope.config.isGood ) {
												$scope.venueList[key].venueName += ', ' + $scope.eventMonthList[key_month].monthName;
											}

										}

									}

								}

							}

						}

					}

				}

			}

			$scope.addTimeValue = function() {

				if( $scope.config.month.ID ) {

					for( var key in $scope.venueList ) {

						if( $scope.venueList[key].venueId == $scope.config.venue.ID ) {

							var days = [];
							for (var key_list in $scope.venueList[key].actionEventList) {

								var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
								var dayObject = moment( $scope.venueList[key].actionEventList[key_list].day, 'DD.MM.YYYY' );
								if( date[1] == $scope.config.month.ID && $.inArray(dayObject.dayOfYear(), days) == -1 ) {

									days.push( dayObject.dayOfYear() );

								}

							}

							for( var key_days in days ) {

								var count = 0;
								for (var key_list in $scope.venueList[key].actionEventList) {
									var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
									var dayObject = moment( $scope.venueList[key].actionEventList[key_list].day, 'DD.MM.YYYY' );
									if( $scope.venueList[key].venueId == $scope.config.venue.ID && days[key_days] == dayObject.dayOfYear() ){

										count += 1;

									}

								}

								if( count == 1 ){

									for (var key_list in $scope.venueList[key].actionEventList) {

										var date = $scope.venueList[key].actionEventList[key_list].day.split('.');
										var dayObject = moment( $scope.venueList[key].actionEventList[key_list].day, 'DD.MM.YYYY' );
										if( days[key_days] == dayObject.dayOfYear() ) {

											var time = $scope.venueList[key].actionEventList[key_list].time;
											for (var key_day in $scope.eventDayList) {

												if( $scope.eventDayList[key_day].ID == days[key_days] && $scope.eventDayList[key_day].name.indexOf(time) == -1 ){

													$scope.eventDayList[key_day].name += ' ' + time;

													if( $scope.eventDayList.length == 1 && $scope.eventMonthList.length == 1 && $scope.eventMonthList[0].monthName.indexOf(time) == -1 && !$scope.config.isGood ) {

														$scope.eventMonthList[0].monthName += ' ' + $scope.eventDayList[key_day].name;

													}

												}

											}

										}

									}

								}

							}

						}

					}

				}

			}

			// функционал выделения нескольких мест мышкой
			$scope.shiftPressed = false;
			$(document).on('mousedown', '#sheme', function(e){
				if( $scope.shiftPressed ){
					$(".ghost-select").addClass("ghost-active");
					$(".ghost-select").css({
						'left': e.pageX,
						'top': e.pageY
					});
					initialW = e.pageX;
					initialH = e.pageY;
					$(document).bind( "mouseup", selectElements );
					$(document).bind( "mousemove", openSelector );
				}
			});
			$(document).on('keydown', function(e){
				if( e.keyCode == 16 ){
					$scope.shiftPressed = true;
					if( typeof panZoom != 'undefined' ){
						panZoom.disablePan();
					}
					$('body').css('overflow-y', 'hidden');
				}
			});
			$(document).on('keyup', function(e){
				if( e.keyCode == 16 ){
					$scope.shiftPressed = false;
					$(document).unbind( "mouseup", selectElements );
					$(document).unbind( "mousemove", openSelector );
					$(".ghost-select").removeClass("ghost-active");
					if( typeof panZoom != 'undefined' ){
						panZoom.enablePan();
					}
					$('body').css('overflow-y', 'auto');
				}
			});
			function selectElements(e) {
				$(document).unbind( "mouseup", selectElements );
				$(document).unbind( "mousemove", openSelector );

				var maxX = 0;
				var minX = 5000;
				var maxY = 0;
				var minY = 5000;

				// собираем массивы на бронирование / разбронирование
				var toReserve = [];
				var toUnreserve = [];
				$("#sheme svg circle").each(function () {
					var aElem = $(".ghost-select");
					var bElem = $(this);
					var result = doObjectsCollide(aElem, bElem);
					if (result == true) {

						var element = bElem.context;
						var elementId = element.getAttribute("id");  //id элемента
						var seatId = element.getAttribute("sbt:id");  //id места в БС
						var state = element.getAttribute("sbt:state");//статус места
						var cat = element.getAttribute("sbt:cat");    //категория, описанная в svg документе
						var categoryName = $scope.findByAttributeValue("sbt:category", "sbt:index", cat).getAttribute("sbt:name"); //имя категории
						var categoryPrice = $scope.findByAttributeValue("sbt:category", "sbt:index", cat).getAttribute("sbt:price"); //цена категории
						var row = element.parentElement.getAttribute("sbt:row");    //номер ряда
						var seat = element.getAttribute("sbt:seat");                //номер места в ряду
						var sector = element.parentElement.getAttribute("sbt:sect");//название сектора

						//если уже нажимали на место и результат еще не вернулся
						if (state == 1 || (state == 2 && bElem.context.hasAttribute("sbt:owner"))) {
							if (element.hasAttribute("opacity")) return;
							element.setAttribute("opacity", "0.2");
							var class_ = element.getAttribute("class");
						}

						if (state == 1) {
							toReserve.push(seatId);
						} else if (state == 2) {
							toUnreserve.push(seatId);
						}

						var aElemPos = bElem.offset();
						var bElemPos = bElem.offset();
						var aW = bElem.width();
						var aH = bElem.height();
						var bW = bElem.width();
						var bH = bElem.height();

						var coords = checkMaxMinPos(aElemPos, bElemPos, aW, aH, bW, bH, maxX, minX, maxY, minY);
						maxX = coords.maxX;
						minX = coords.minX;
						maxY = coords.maxY;
						minY = coords.minY;
						var parent = bElem.parent();
						if (bElem.css("left") === "auto" && bElem.css("top") === "auto") {
							bElem.css({
								'left': parent.css('left'),
								'top': parent.css('top')
							});
						}
					}
				});

				if (toReserve.length > 0) {
					console.log(toReserve);
					var ticket_reserved;
					ticket_reserved = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, seatList: toReserve, type: 'RESERVE_BY_PLACE', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( ticket_reserved ){
						ticket_reserved.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
								/* v1.1 */
								$("#sheme svg circle").each(function () {
									$(this).css("opacity", 1);
								});
								/* /v1.1 */
							} else if(results.resultCode == 0) {
								for (var key in toReserve) {
									var element = $scope.findByAttributeValue("circle", "sbt:id", toReserve[key]);
									var class_ = element.getAttribute("class");
									element.removeAttribute("opacity");
									element.setAttribute("class", class_ + " st4");
									element.setAttribute("sbt:state", "2");
									$scope.tickets.withPlace.data.push(toReserve[key]);
								}

								// обновляем содержимое корзины
								$rootScope.$broadcast('getCart', { callback: false} );

							}
						});
					}
				}
				if (toUnreserve.length > 0) {
					console.log(toUnreserve);
					var ticket_unreserved = Request.GetRequest({command: 'RESERVATION', userId: $localStorage.userId, sessionId: $localStorage.sessionId, seatList: toUnreserve, type: 'UN_RESERVE', fid: $scope.config.fid, token: $scope.config.token, versionCode: $scope.config.versionCode});
					if( ticket_unreserved ){
						ticket_unreserved.$promise.then(function(results) {
							console.log(results);
							if(results.resultCode == 101) {
								growl.error(results.description);
							} else if(results.resultCode == 0) {
								for (var key in toUnreserve) {
									var element = $scope.findByAttributeValue("circle", "sbt:id", toUnreserve[key]);
									var class_ = element.getAttribute("class");
									element.removeAttribute("opacity");
									element.setAttribute("class", class_.replace(" st4", ""));
									element.setAttribute("sbt:state", "1");
									var key = $scope.tickets.withPlace.data.indexOf(toUnreserve[key]);
									if( key != -1 ){
										$scope.tickets.withPlace.data.splice(key, 1);
									}
								}

								// обновляем содержимое корзины
								$rootScope.$broadcast('getCart', { callback: false} );

							}
						});
					}
				}

				$(".ghost-select").removeClass("ghost-active");
				$(".ghost-select").width(0).height(0);
			}

			function openSelector(e) {
				var w = Math.abs(initialW - e.pageX);
				var h = Math.abs(initialH - e.pageY);
				$(".ghost-select").css({
					'width': w,
					'height': h
				});
				if (e.pageX <= initialW && e.pageY >= initialH) {
					$(".ghost-select").css({
						'left': e.pageX
					});
				} else if (e.pageY <= initialH && e.pageX >= initialW) {
					$(".ghost-select").css({
						'top': e.pageY
					});
				} else if (e.pageY < initialH && e.pageX < initialW) {
					$(".ghost-select").css({
						'left': e.pageX,
						"top": e.pageY
					});
				}
			}
			
			function doObjectsCollide(a, b) {
				var aTop = a.offset().top - 10;
				var aLeft = a.offset().left - 10;
				var bTop = b.offset().top + 10;
				var bLeft = b.offset().left;

				return !(
				((aTop + a.height() + 10) < (bTop)) ||
				(aTop > (bTop + b.height() + 10)) ||
				((aLeft + a.width() + 10) < bLeft) ||
				(aLeft > (bLeft + b.width() + 10))
				);
			}

			function checkMaxMinPos(a, b, aW, aH, bW, bH, maxX, minX, maxY, minY) {
				'use strict';
				if (a.left < b.left) {
					if (a.left < minX) {
						minX = a.left;
					}
				} else {
					if (b.left < minX) {
						minX = b.left;
					}
				}
				if (a.left + aW > b.left + bW) {
					if (a.left > maxX) {
						maxX = a.left + aW;
					}
				} else {
					if (b.left + bW > maxX) {
						maxX = b.left + bW;
					}
				}
				if (a.top < b.top) {
					if (a.top < minY) {
						minY = a.top;
					}
				} else {
					if (b.top < minY) {
						minY = b.top;
					}
				}
				if (a.top + aH > b.top + bH) {
					if (a.top > maxY) {
						maxY = a.top + aH;
					}
				} else {
					if (b.top + bH > maxY) {
						maxY = b.top + bH;
					}
				}
				return {
					'maxX': maxX,
					'minX': minX,
					'maxY': maxY,
					'minY': minY
				};
			}

		});

	}

})();