<?
	$version = '2.012';
	$updated = '09.12.2020';
?>
