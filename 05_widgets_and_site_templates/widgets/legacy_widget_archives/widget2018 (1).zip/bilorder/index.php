<?php include_once('config.php'); ?>
<!DOCTYPE html>
<html id = "bil" lang="ru" ng-app="bilpro" ng-controller = "bilController">
<head>
	<meta charset="UTF-8">
	<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1">
	<title>{{localization.event.title}}</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<link rel="stylesheet" href="lib/angular-growl/angular-growl.min.css">
	<link rel="stylesheet" href="styles/basket_v<?=$version;?>.css">
	<link rel="stylesheet" href="styles/style_v<?=$version;?>.css">
	<link rel="stylesheet" href="styles/custom-style_v<?=$version;?>.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-animate.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-resource.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular-sanitize.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/ngStorage/0.3.6/ngStorage.min.js"></script>
	<script src = "lib/angular-growl/angular-growl.min.js"></script>
	<script src = "lib/svg-pan-zoom.min.js"></script>
	<script src = "lib/jquery.maskedinput.min.js"></script>
	<script src = "lib/modernizr-custom.js"></script>
	<script src = "lib/hammer.min.js"></script>
	<script src = "lib/moment.min.js"></script>
	<script src = "scripts/script_v<?=$version;?>.js"></script>
	<script src = "scripts/basket_v<?=$version;?>.js"></script>
	<script src = "scripts/header_v<?=$version;?>.js"></script>
	<!--[if lt IE 9]>
	<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body class = "home-page">	
	<div class = "bil-main">
		<div growl></div>
		<div class = "bil-version"><?=$version;?> <?=$updated;?></div>
		<div class = "bil-header" ng-controller = "bilHeader">
			<?php include_once('parts/mobile-header.php'); ?>
			<div class = "bil-wrapper">
				<div class = "bil-title" ng-show = "config.action.name">
					<h1 class = "fade-in">{{config.action.name}}</h1>
					<div class = "menuTrigger" ng-click = "openMenu()">
						<svg viewBox="0 0 32 32"><path d="M4,10h24c1.104,0,2-0.896,2-2s-0.896-2-2-2H4C2.896,6,2,6.896,2,8S2.896,10,4,10z M28,14H4c-1.104,0-2,0.896-2,2 s0.896,2,2,2h24c1.104,0,2-0.896,2-2S29.104,14,28,14z M28,22H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h24c1.104,0,2-0.896,2-2 S29.104,22,28,22z"/></svg>
					</div>
					<div class = "authTrigger" ng-click = "openAuth()">
						<svg viewBox="0 0 350 350"><path d="M175,171.173c38.914,0,70.463-38.318,70.463-85.586C245.463,38.318,235.105,0,175,0s-70.465,38.318-70.465,85.587 C104.535,132.855,136.084,171.173,175,171.173z"/><path d="M41.909,301.853C41.897,298.971,41.885,301.041,41.909,301.853L41.909,301.853z"/><path d="M308.085,304.104C308.123,303.315,308.098,298.63,308.085,304.104L308.085,304.104z"/><path d="M307.935,298.397c-1.305-82.342-12.059-105.805-94.352-120.657c0,0-11.584,14.761-38.584,14.761 s-38.586-14.761-38.586-14.761c-81.395,14.69-92.803,37.805-94.303,117.982c-0.123,6.547-0.18,6.891-0.202,6.131 c0.005,1.424,0.011,4.058,0.011,8.651c0,0,19.592,39.496,133.08,39.496c113.486,0,133.08-39.496,133.08-39.496 c0-2.951,0.002-5.003,0.005-6.399C308.062,304.575,308.018,303.664,307.935,298.397z"/></svg>
					</div>
					<?php include_once('parts/auth-popup.php'); ?>
				</div>
				<div ng-show = "config.action.description" class = "bil-description fade-in">{{config.action.description}}</div>
				<div ng-show = "config.action.venue" class = "bil-venue fade-in">{{config.action.venue}}</div>
				<div class = "loader-wrapper" ng-show = "!config.action.name && !config.action.description && !config.action.venue">
					<div class="loader"></div>
				</div>
			</div>
		</div>
		<div class = "bil-content">
			<div class="ghost-select"><span></span></div>
			<div class = "bil-wrapper">
				<div class = "email-get" ng-show = "contentLoaded && !config.noResults">
					<form name = "userMail" class = "input-group" ng-submit = "SetEmail()" novalidate>
						<input class = "form-control" type = "email" placeholder = "{{localization.emailPlaceholder}}" ng-model="email" ng-pattern="/^([a-zA-Z0-9_-]+\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*\.[a-zA-Z]{2,6}$/" required>
						<span class = "input-group-btn">
							<button class = "btn btn-default" type = "submit" ng-disabled="userMail.$invalid || showConfirm">{{localization.settings.emailBtnTxt}}</button>
						</span>
					</form>
				</div>
				<div class = "email-confirm" ng-show = "showConfirm">
					<div class = "form-label">{{emailConfirmMsg}} <span>{{email}}</span></div>
					<form class = "input-group" ng-submit = "ConfirmEmail()" novalidate>
						<input class = "form-control" type = "text" ng-model="code" placeholder = "{{localization.settings.emailConfirmPlaceholderTxt}}" required>
						<span class = "input-group-btn">
							<button class = "btn btn-default" type = "submit">{{localization.settings.emailConfirmBtnTxt}}</button>
						</span>
					</form>
				</div>
				<div class = "promoCodes-set" ng-show = "showPromoCodes">
					<div class = "form-label">{{localization.codes.setTitle}}</div>
					<form class = "input-group" ng-submit = "SetPromoCodes()" novalidate>
						<input class = "form-control" type = "text" ng-model="promoCodes" placeholder = "{{localization.codes.setPlaceholderTxt}}" required>
						<span class = "input-group-btn">
							<button class = "btn btn-default" type = "submit" ng-disabled="disabledPromoCodes">{{localization.codes.setBtn}}</button>
						</span>
					</form>
				</div>
				<div class = "venue-list" ng-class = "{'fade-in': config.venue.show}" ng-show = "config.venue.show">
					<div class = "venueItem" ng-class="{active: config.venue.ID == venue.venueId}" ng-repeat="venue in venueList" ng-click="SelectVenue(venue.venueId)">{{venue.venueName}}</div>
				</div>
				<div class = "eventMonth-list" ng-class = "{'fade-in': config.month.show}" ng-show = "config.month.show">
					<div class = "eventMonthItem" ng-class="{active: config.month.ID == eventMonth.monthId}" ng-repeat="eventMonth in eventMonthList" ng-click="SelectMonth(eventMonth.monthId)">{{eventMonth.monthName}}</div>
				</div>
				<div class = "eventDay-list" ng-class="{'fade-in': config.day.show}" ng-show = "config.day.show">
					<div class = "eventDayItem" ng-class="{active: config.day.ID == eventDay.ID}" ng-repeat="eventDay in eventDayList" ng-click="SelectDay(eventDay.ID)">
						{{eventDay.name}}
					</div>
				</div>
				<div class = "eventTime-list" ng-class="{'fade-in': config.time.show}" ng-show = "config.time.show">
					<div class = "eventTimeItem" ng-class="{active: config.time.ID == eventTime.timeId}" ng-repeat="eventTime in eventTimeList" ng-click="SelectTime(eventTime.timeId)">{{eventTime.timeValue}}</div>
				</div>
				<div class = "placement">
					<div class = "placement-title" ng-show = "tickets.withoutPlace.show">{{localization.withoutPlace}}</div>
					<div class = "placement-withoutPlace">
						<div class = "placementItem clearfix" ng-repeat = "category in categories | orderBy:'price'">
							<div class = "placementItem-title">«{{category.name}}»</div>
							<div class = "placementItem-price">{{category.price}} {{localization.currency}}</div>
							<div class = "placementItem-actions">
								<div class = "input-group">
									<div class = "input-group-btn">
										<div class = "placementItem-menus btn-default btn" ng-click = "ChangeCount(category.ID, 'minus')" ng-disabled = "config.email.disabled">-</div>
									</div>
									<input class = "form-control" type = "text" ng-model = "category.count" ng-change = "WithoutPlaceReserve(category.ID, category.count)" numbers-only ng-disabled = "config.email.disabled">
									<div class = "input-group-btn">
										<div class = "placementItem-plus btn-default btn" ng-click = "ChangeCount(category.ID, 'plus')" ng-disabled = "config.email.disabled">+</div>
									</div>
								</div>
							</div>
							<div class = "placementItem-availability">
								{{localization.available}} {{category.result}}
							</div>
						</div>
					</div>
					<div class = "placement-title" ng-show = "tickets.withPlace.show">{{localization.withPlace}}</div>
					<div class = "placementLegend clearfix">
						<div class = "placementLegend-left" ng-show = "config.sheme.show">
							<div class = "placementLegend-wrapper"></div>
						</div>
						<div class = "placementLegend-right" ng-show = "config.sheme.show">
							<div class = "placementLegend-wrapper">
								<div class = "placementLegend-item"><i style = "background-color: #999"></i> - {{localization.event.legend.sold}}</div>
								<div class = "placementLegend-item"><i style = "background-color: #fff"></i> - {{localization.event.legend.none}}</div>
								<div class = "placementLegend-item"><i style = "background-color: #4d4d4d"></i> - {{localization.event.legend.reserved}}</div>
								<div class = "placementLegend-item"><i style = "background-color: #ff00cc"></i> - {{localization.event.legend.myTickets}}</div>
							</div>
						</div>
					</div>
					<div class = "placement-title" ng-show = "tickets.withPlace.noResult">{{localization.noPlace}}</div>
					<div class = "loader-wrapper" ng-show = "config.sheme.loading">
						<div class="loader"></div>
					</div>
					<div class = "placementSheme">
						<div id = "sheme"></div>
						<div class="controls" ng-show = "config.sheme.show">
							<div class="btn-group btn-group-lg">
								<button type="button" class="btn btn-info" ng-click="zoomOut()">&nbsp;-&nbsp;</button>
								<button type="button" class="btn btn-info" ng-click="zoomIn()">&nbsp;+&nbsp;</button>								
							</div>
						</div>
					</div>
				</div>
				<div class = "loader-wrapper" ng-show = "!contentLoaded">
					<div class="loader"></div>
				</div>
			</div>
		</div>
		<?php include_once('parts/basket-popup.php'); ?>
	</div>
</body>
</html>
